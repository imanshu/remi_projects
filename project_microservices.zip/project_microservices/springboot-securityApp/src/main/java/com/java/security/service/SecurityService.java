package com.java.security.service;

import java.nio.charset.Charset;

import org.apache.commons.codec.binary.Base64;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

//@Service("security-service")
@SuppressWarnings("unchecked")
public class SecurityService {
	
	/*
	@Autowired
	RestTemplate restTemplate;
	

	public JSONObject getToken() {
		String url = "http://localhost:1000/oauth/token?grant_type=password&username=user&password=password";
		//JSONObject request = new JSONObject();
		//request.put("username", "user" );
		//request.put("password", "password");
		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization","Basic bXktY2xpZW50czpzZWNyZXQ=");
		//HttpEntity<String> entity = new HttpEntity<String>(createHeaders("my-clients","secret"));

		HttpEntity<String> entity = new HttpEntity<String>(headers);

		ResponseEntity<JSONObject> response = restTemplate.exchange(url, HttpMethod.POST, entity, JSONObject.class);
		System.out.println(response);
		return response.getBody();

	}
	
	HttpHeaders createHeaders(String username, String password){
		   return new HttpHeaders() {{
		         String auth = username + ":" + password;
		         byte[] encodedAuth = Base64.encodeBase64( 
		            auth.getBytes(Charset.forName("US-ASCII")) );
		         String authHeader = "Basic " + new String( encodedAuth );
		         set( "Authorization", authHeader );
		      }};
		}
		*/
	
	

}
