package com.java.security;

import java.util.List;
import java.nio.charset.Charset;
import java.util.Arrays;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScans;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.client.DefaultOAuth2ClientContext;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.security.oauth2.client.token.grant.password.ResourceOwnerPasswordResourceDetails;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableOAuth2Client;
import org.springframework.web.client.RestTemplate;

import com.java.security.config.CustomerUserDetail;
import com.java.security.domain.Role;
import com.java.security.domain.User;
import com.java.security.repository.UserRepository;
import com.java.security.service.AccessTokenService;
import com.java.security.service.SecurityService;
import com.java.security.service.UserService;

@SpringBootApplication
@ComponentScan(basePackages = {"com.java.security.config","com.java.security.service","com.java.security.controller"})
@EnableOAuth2Client
public class SecurityApplication implements CommandLineRunner{
	private Logger log = LoggerFactory.getLogger(this.getClass().getName());
	
	/*
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	@Autowired
	@Qualifier("security-service")
	SecurityService securityService;
	*/
	
	@Autowired
	@Qualifier("token-service")
	AccessTokenService tokenService;
	
	@Autowired
	UserRepository repository;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SpringApplication.run(SecurityApplication.class, args);
		
	}
	
	/*
	@Bean
	public RestTemplate restTemplate(RestTemplateBuilder builder) {
		return builder.build();
	}


	@Autowired
	public void authenticationManager(AuthenticationManagerBuilder builder, UserRepository repository, UserService service) throws Exception {
	    service.save(new User("user", "password",Arrays.asList(new Role("user"),new Role("admin"))));
		System.out.println("get:" + repository.findAll());
		builder.userDetailsService(userDetailsService(repository)).passwordEncoder(passwordEncoder);
	}
	
	public UserDetailsService userDetailsService(final UserRepository repository) {
		return name -> new CustomerUserDetail(repository.findByUserName(name));
	}
*/

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		HttpHeaders headers = new HttpHeaders();
		headers = createHeaders("my-clients","secret");
		
		log.info(headers.toString());
		
		log.info(tokenService.MyService().toString());
		log.info("source#########" + tokenService.sourceInfo());
		//log.info(getToken().toString());
		/*
		
		ResourceOwnerPasswordResourceDetails resourceDetails = new ResourceOwnerPasswordResourceDetails();
		 resourceDetails.setUsername("user");
	     resourceDetails.setPassword("password");
	     resourceDetails.setAccessTokenUri("http://localhost:1000/oauth/token");
	     resourceDetails.setClientId("my-clients");
	     resourceDetails.setClientSecret("secret");
	     resourceDetails.setGrantType("password");
	    // resourceDetails.setScope(asList("read", "write"));
	     DefaultOAuth2ClientContext clientContext = new DefaultOAuth2ClientContext();

	     OAuth2RestTemplate restTemplate = new OAuth2RestTemplate(resourceDetails, clientContext);
	     restTemplate.setMessageConverters((List<HttpMessageConverter<?>>) new MappingJackson2HttpMessageConverter());
	     final String greeting = restTemplate.getForObject("http://localhost:1000/greeting", String.class);

	     //System.out.println(greeting);
	      * */
	      

		
	}
	/*
    RestTemplate restTemplate;
	

	public JSONObject getToken() {
		RestTemplate restTemplate = null;
		String url = "http://localhost:1000/oauth/token?grant_type=password&username=user&password=password";
		//String url1 = "http://localhost:1000/oauth/token?grant_type=client_credentials&client_id=my-clients&client_secret=secret";
		//JSONObject request = new JSONObject();
		//request.put("username", "user" );
		//request.put("password", "password");
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.add("Authorization", "Basic bXktY2xpZW50czpzZWNyZXQ=");
		//headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> entity = new HttpEntity<String>(headers);
		//restTemplate.setRequestFactory(new HttpComponentsClientHttpRequestFactory());

		ResponseEntity<JSONObject> response = restTemplate.exchange(url, HttpMethod.POST, entity, JSONObject.class);
		//ResponseEntity<JSONObject> response = restTemplate.postForEntity(url, entity, JSONObject.class);
		//String value = restTemplate.postForObject(url, entity, String.class);
		//System.out.println(value);
		//System.out.println(response);
		//System.out.println(response);
		
		return response.getBody();

	}
	*/
	HttpHeaders createHeaders(String username, String password){
		   return new HttpHeaders() {{
		         String auth = username + ":" + password;
		         byte[] encodedAuth = Base64.encodeBase64( 
		            auth.getBytes(Charset.forName("US-ASCII")) );
		         String authHeader = "Basic " + new String( encodedAuth );
		         set( "Authorization", authHeader );
		      }};
		}
		
	
}
