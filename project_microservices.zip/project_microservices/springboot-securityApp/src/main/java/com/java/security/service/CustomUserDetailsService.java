package com.java.security.service;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.java.security.config.CustomerUserDetail;
import com.java.security.domain.Role;
import com.java.security.domain.User;
import com.java.security.repository.UserRepository;

@Service
public class CustomUserDetailsService implements UserDetailsService{
    
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private UserService service;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		service.save(new User("user", "password",Arrays.asList(new Role("user"),new Role("admin"))));
		User user = userRepository.findByUserName(username);
		User sampleUser = new User("user", "password",Arrays.asList(new Role("user"),new Role("admin")));
		return new CustomerUserDetail(user);
	}
	
	@Autowired
	public CustomUserDetailsService(UserRepository userRepository) {
		this.userRepository = userRepository;
	}
}
