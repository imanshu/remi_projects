package com.java.security.validation;

import org.springframework.stereotype.Component;

@Component
public class UserValidation {

}
