package com.java.security.config;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableOAuth2Client;

import com.java.security.domain.Role;
import com.java.security.domain.User;
import com.java.security.repository.UserRepository;
import com.java.security.service.CustomUserDetailsService;
import com.java.security.service.UserService;

@Configuration
@EnableWebSecurity
@EnableOAuth2Client
public class Auth2Configuration extends WebSecurityConfigurerAdapter {
	

	@Autowired
	private PasswordEncoder passwordEncoder;
	
	@Autowired
	UserService userService;
	
	@Autowired
	CustomUserDetailsService userDetailsService; 

	@Override
	protected void configure(AuthenticationManagerBuilder builder) throws Exception {
		 builder.userDetailsService(userDetailsService)
		 .passwordEncoder(passwordEncoder);
	}
	 
	 @Override
     @Bean
	 public AuthenticationManager authenticationManagerBean() throws Exception {
		 return super.authenticationManagerBean();
   }

}
