package com.java.security.controller;

import java.io.IOException;
import java.util.Enumeration;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.java.security.service.AccessTokenService;
import com.java.security.service.SecurityService;

@Controller
@ComponentScan(basePackages = {"com.java.security.config","com.java.security.service","com.java.security.controller"})
public class SecurityController {
	
	
	@Autowired
	@Qualifier("token-service")
	AccessTokenService tokenService;
	
	@RequestMapping(value = "/HI")
	public String helloController(){
		
		return "hiiii";
	}
	
	@RequestMapping(path="/private",method=RequestMethod.GET)
	@ResponseBody
	public String accessToken(HttpServletRequest request,HttpServletResponse response ) {
		Enumeration<String> getheader = request.getHeaders("Authorization");
		System.out.println(getheader);
		
		String header = tokenService.MyService().toString();
		System.out.println(header);
		HttpHeaders responseHeaders = new HttpHeaders();
		responseHeaders.add("Authorization",  "Bearer " + header);
		System.out.println(responseHeaders);
		//return new HttpEntity<String>("hiii",responseHeaders);
		return "hiii";
	}
	@RequestMapping(path="/aprivate",method=RequestMethod.GET)
	public String paccessToken(HttpServletRequest request,HttpServletResponse response ) {
		String header = tokenService.MyService().toString();
		System.out.println("token:####### " + header);
		response.setHeader("Authorization", "Bearer " + header);
		System.out.print(response);
		//return "hello";
		//return "redirect:http://localhost:1000/private";
		return "redirect:http://localhost:1000/private?access_token="+header;
	}
	/*
	@RequestMapping(path="/oauth/token?grant_type=client_credentials&client_id=my-clients&client_secret=secret",method=RequestMethod.POST)
	public String getaccesstoken(HttpServletRequest request,HttpServletResponse response) throws IOException {
		String jsonString = request.getReader().lines().collect(Collectors.joining(System.lineSeparator()));
		return jsonString;
	}
	
	@RequestMapping(path="/private/{redirecturi}",method=RequestMethod.GET,produces="application/json; charset=UTF-8")
	public String securityController(@PathVariable("redirecturi") String redirecturi) {
		
		
		return redirecturi;
	}
	*/

}
