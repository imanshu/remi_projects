INSERT INTO user (id, username, password) VALUES (11, 'admin', 'b8f57d6d6ec0a60dfe2e20182d4615b12e321cad9e2979e0b9f81e0d6eda78ad9b6dcfe53e4e22d1');
INSERT INTO user (id, username, password) VALUES (12, 'user', 'd6dfa9ff45e03b161e7f680f35d90d5ef51d243c2a8285aa7e11247bc2c92acde0c2bb626b1fac74');

INSERT INTO roles (roleId, name) VALUES (101,'user');
INSERT INTO roles (roleId, name) VALUES (102,'admin');