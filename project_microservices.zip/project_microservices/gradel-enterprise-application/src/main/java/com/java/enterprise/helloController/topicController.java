package com.java.enterprise.helloController;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.java.enterprise.topic.domain.topic;
import com.java.enterprise.topic.service.topicService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;


@RestController
@RequestMapping("/api")
@Api(value = "course-api-service" , description = "sample service for course api")
public class topicController {
	
	@Autowired
	private topicService service;
	
	@ApiOperation(value = "View a list of available courses", response = topic.class)
	@RequestMapping(path="/topics",method=RequestMethod.GET,produces="application/json; charset=UTF-8")
	@ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully retrieved list"),
            @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
            @ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
            @ApiResponse(code = 404, message = "The resource you were trying to reach is not found")
    }
    )
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "name", value = "User's name", required = false, dataType = "string", paramType = "query"),
	    @ApiImplicitParam(name = "email", value = "User's email", required = false, dataType = "string", paramType = "query"),
	    @ApiImplicitParam(name = "id", value = "User ID", required = false, dataType = "long", paramType = "query")
	  })
	public List<topic> returnTopic() {
		//return new topic(1,"java","java description");
		return service.getAllToipcs();
	}
	@ApiOperation(value = "get course by it's id", response = Iterable.class)
	@RequestMapping(path="/topics/{id}",method=RequestMethod.GET,produces="application/json; charset=UTF-8")
	public topic returnTopicById(@PathVariable("id") int id) {
		
		return service.getTopicById(id);
	}
	
	@ApiOperation(value = "post a topic/course", response = Iterable.class)
	@RequestMapping(path="/topics",method=RequestMethod.POST)
	public boolean addTopic(@RequestBody topic topic) {
		
		return service.saveTopic(topic);
	}
	
	@ApiOperation(value = "update a topic", response = Iterable.class)
	@RequestMapping(path="/topics",method=RequestMethod.PUT)
	public boolean updateTopic(@RequestBody topic topic) {
		return service.updateTopic(topic);
	}

}
