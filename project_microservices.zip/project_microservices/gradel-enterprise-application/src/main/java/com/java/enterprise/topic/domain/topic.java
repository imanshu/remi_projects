package com.java.enterprise.topic.domain;

import javax.persistence.Entity;
import javax.persistence.Id;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;


@Entity
@ApiModel(value="DifferentModel", description="Sample model for the documentation")
public class topic {

	@Id
	@ApiModelProperty(notes = "The id of the topic", required = true)
	int id;
	
	@ApiModelProperty(notes = "The name of the topic")
	String name;
	
	@ApiModelProperty(notes = "The description of the topic")
	String description;
	
	@ApiModelProperty(notes = "The id of the topic", required = true)
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@ApiModelProperty(notes = "The name of the topic")
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@ApiModelProperty(notes = "The description of the topic")
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @param id
	 * @param name
	 * @param description
	 */
	public topic(int id, String name, String description) {
		super();
		this.id = id;
		this.name = name;
		this.description = description;
	}
	/**
	 * @param id
	 * @param name
	 */
	public topic(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	/**
	 * 
	 */
	public topic() {
		super();
	}
}
