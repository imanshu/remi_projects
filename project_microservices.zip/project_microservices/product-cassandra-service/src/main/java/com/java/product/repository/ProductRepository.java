package com.java.product.repository;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.Session;
import com.datastax.driver.mapping.Mapper;
import com.datastax.driver.mapping.MappingManager;
import com.java.product.config.CassandraConfiguration;
import com.java.product.domain.Product;

import ch.qos.logback.classic.Logger;

@Repository
public class ProductRepository {
	
	private static Logger logger = (Logger) LoggerFactory.getLogger(ProductRepository.class);

	private Cluster cluster;

	private Session session;
	
	private ProductAccessor productAccessor;
	
	private MappingManager manager;
	
	private Mapper<Product> mapper;
	
	@Autowired
	private CassandraConfiguration configuration;
	
	
	@PostConstruct
	private void initialize() {

		cluster	= Cluster.builder().addContactPoints(configuration.getContactPoints()).build();
		session = cluster.connect(configuration.getKeypacename());
		manager = new MappingManager(session);
		mapper = manager.mapper(Product.class);
		productAccessor = manager.createAccessor(ProductAccessor.class);

		
	}
	
	@PreDestroy
	private void close() {
		logger.info("session ended");
		session.close();
		cluster.close();
	}
	
	public Product getById(int id) {
		
		return productAccessor.getById(id);
	}
	
	public void saveProduct(Product product) {
		
		mapper.save(product);
	}


}
