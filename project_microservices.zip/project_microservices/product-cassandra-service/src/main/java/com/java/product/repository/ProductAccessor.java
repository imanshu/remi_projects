package com.java.product.repository;

import com.datastax.driver.mapping.annotations.Accessor;
import com.datastax.driver.mapping.annotations.Query;
import com.java.product.domain.Product;

@Accessor
public interface ProductAccessor {
	
	@Query("SELECT * FROM apikeyspace.products where id = ?")
	Product getById(int id);
	
}
