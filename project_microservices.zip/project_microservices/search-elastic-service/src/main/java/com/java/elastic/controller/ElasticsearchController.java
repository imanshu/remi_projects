package com.java.elastic.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.java.elastic.domain.Product;
import com.java.elastic.service.SearchService;

@RestController
public class ElasticsearchController {
	
	@Autowired
	SearchService service;
	
	@RequestMapping(value = "/search", method = RequestMethod.GET)
	public List<Product> getProducts(@RequestParam  Map<String,String> queryParameters){
		
		return service.getProducts(queryParameters);
	}
	
	@RequestMapping(value = "/search/all", method = RequestMethod.GET)
	public List<Product> getDefaultProducts(){
		
		return service.getDefaultResult();
	}

}
