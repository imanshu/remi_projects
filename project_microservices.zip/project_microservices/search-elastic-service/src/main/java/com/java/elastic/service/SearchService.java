package com.java.elastic.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.java.elastic.domain.Product;

@Service
public interface SearchService {
	
	public List<Product> getProducts(Map<String,String> queryParameters);
	
	public List<Product> getDefaultResult();

}
