package com.java.elastic.config;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.InetSocketTransportAddress;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

import lombok.Getter;

@Component
public class ElasticClient {
	
	@Autowired
	private ElasticConfiguration configuration;
	private @Getter TransportClient client;
	

	public TransportClient getClient() {
		return client;
	}

	@PostConstruct
	private void initialize() {
	
		Settings settings = Settings.settingsBuilder().put("cluster.name",configuration.getClusterName()).build();
		client = TransportClient.builder().settings(settings).build().addTransportAddress(new InetSocketTransportAddress(configuration.getContactPoints().get(0),configuration.getPort()));
        //client = TransportClient.builder().settings(settings).build().addTransportAddress(new InetSocketTransportAddress(InetAddress.getByName("localhost"), 9300));
	}
	
	@PreDestroy
	private void close() {
		client.close();
	}

}
