package com.java.elastic.load;



public class Loader {

}
