package com.cognizant.training.composite.client;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.cognizant.training.composite.domain.Product;

// This is needed otherwise the class will not be available to be loaded during the startup
@Component
public class ProductFallback implements ProductClient {
	private static Logger logger = LoggerFactory.getLogger(ProductFallback.class);

	@Override
	public Product getProduct(long id) {
		logger.error("invoking the fallback");
		Product product = new Product();
		product.setId(id);
		product.setName("fallback name");
		return product;
	}

	@Override
	public boolean saveProduct(Product product) {
		logger.error("Product not saved.Invoked the fallback for product id: " + product.getId() + " name: " + product.getName());
		return false;
	}
	
	


}
