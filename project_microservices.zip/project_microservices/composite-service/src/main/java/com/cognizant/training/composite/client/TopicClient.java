package com.cognizant.training.composite.client;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cognizant.training.composite.domain.Product;
import com.cognizant.training.composite.domain.topic;

import feign.Headers;

@FeignClient(name = "gradle-enterprise-application", fallback = TopicFallback.class)
public interface TopicClient {
	
	@RequestMapping(method = RequestMethod.GET, value = "/topics/{id}")
	@Headers("Content-Type: application/json")
	topic getTopicById(@PathVariable(value = "id") int id);
	
	@RequestMapping(method = RequestMethod.POST, value = "/topics")
	boolean saveTopic(@RequestBody topic topic);

}
