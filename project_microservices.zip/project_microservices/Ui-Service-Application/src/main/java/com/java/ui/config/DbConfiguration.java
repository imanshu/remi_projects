package com.java.ui.config;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

//@Configuration
public class DbConfiguration {
 
	//@Bean(name = "dataSource") 
	public DriverManagerDataSource dataSource() {
	     DriverManagerDataSource driverManagerDataSource = new DriverManagerDataSource();
	     driverManagerDataSource.setDriverClassName("org.h2.driver");
	     driverManagerDataSource.setUrl("jdbc:h2:tcp://localhost/~/user");
	     driverManagerDataSource.setUsername("sa");
	     return driverManagerDataSource;
	 }

}
