export default {
	authors:[],
	courses:[],
	ajaxCallsInProgress:0
}