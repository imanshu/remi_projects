import React from 'react';
import {Link} from 'react-router';
import WalImage from '../common/WalImageSlide';
import Articles from '../articles/Articles';
import HeroSlide from '../img/no1.png';
import PhotoSlide from '../img/no2.jpg';
import FluSlide from '../img/Flu_Shots.png';
import Casual from '../img/collections/col1.jpg';
import Downtown from '../img/collections/col2.jpg';
import Echo from '../img/collections/col3.jpg';

class WalHome extends React.Component{

	render(){
			const DrupalHost='https://mepclouddemoqu478vdavx.devcloud.acquia-sites.com';
		return(
	<div className="row main-wrap align-center">
        <main id="main" className="  columns" role="main">
          <a id="main-content" />
			<section>
            <div className="region region-content">
              <section id="block-obio-page-content" data-block-plugin-id="system_main_block" className="block-obio-page-content block-plugin-id-system-main-block">
                <article data-history-node-id={1} className="node node--type-landing_page node--view-mode-full clearfix">
                  <div>
                    <div className="landing-page-layout clearfix">
                      <div className="row">
                        <div className="small-12 columns">
                          <div className="block-region-top">
                            <WalImage title='General Hero' imgSrc={HeroSlide} />
                            <section className="block-plugin-id-lift-slot" data-lift-slot="15d3a891-4440-46c7-88c0-bad3fdbcaeb5" data-block-plugin-id="lift_slot" data-lift-slot-valid="false" />
                            <Articles />
                            <WalImage title='Photo Cards' imgSrc={PhotoSlide}/>
                            <section data-block-plugin-id="block_content:fd66ee6c-e24a-4dd7-aee5-1f5f564ee398" className="block-content-type-basic block-plugin-id-block-content block-content block-content__basic block-content__basic--full">
                              <div className="hero-block block-content__content block-content__content--basic block-content__content--basic--full"><div className="full-width-inner"><div className="basic-block-fields" />
                                </div><div className="body field field-block-content--body field-name-body field-type-text-with-summary field-label-hidden">
                                  <div className="field-items">
                                    <div className="field-item"><section><div className="container">
                                          <div className="text-center">
                                            <h2>Prints, Photo books and more <strong>ready same day</strong></h2>
                                          </div>
                                        </div>
                                      </section></div>
                                  </div>
                                </div>
                              </div>
                            </section>
                            <section data-block-plugin-id="block_content:50d136b1-6660-485b-adf9-1e8a7f1b5f4d" className="block-content-type-hero block-plugin-id-block-content block-content block-content__hero block-content__hero--full">
                              <div className="hero-block block-content__content block-content__content--hero block-content__content--hero--full">
                                <div className="full-width-row l-over-each">
                                  <div className="l-over-each__item l-over-each__nested-img l-over-each__nested-img--hero hero-alignment-left">
                                    <div className="field-wrapper field field-block-content--field-hero-image field-name-field-hero-image field-type-image field-label-hidden">
                                      <div className="field-items">
                                        <div className="field-item">    <picture>
                                            {/*[if IE 9]><video style="display: none;"><![endif]*/}
                                            <source srcSet={FluSlide} media="all and (min-width: 64em)" type="image/png" />
                                            <source srcSet={FluSlide} media="all and (min-width: 40em)" type="image/png" />
                                            <source srcSet={FluSlide} media="all and (max-width: 39.9375em)" type="image/png" />
                                            {/*[if IE 9]></video><![endif]*/}
                                            <img src="/sites/default/files/styles/hero_image/public/Flu%20Shots.png?itok=6qKFOmyS" alt typeof="foaf:Image" />
                                          </picture>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div className="l-over-each__item">
                                    <div className="full-width-inner align-left">
                                      <div className="medium-7 large-5 column">
                                        <div className="hero-content text-center" style={{background: '#ffffff'}}>
                                          <div style={{color: '#000000'}} className="field-wrapper field field-block-content--field-first-line field-name-field-first-line field-type-string field-label-hidden">
                                            <div className="field-items">
                                              <div className="field-item">$0 Copay on Flu Shots</div>
                                            </div>
                                          </div>
                                          <div style={{color: '#000000'}} className="field-wrapper field field-block-content--field-second-line field-name-field-second-line field-type-string field-label-hidden">
                                            <div className="field-items">
                                              <div className="field-item">With Most Insurance</div>
                                            </div>
                                          </div>
                                          <div className="field-wrapper field field-block-content--field-hero-link field-name-field-hero-link field-type-link field-label-hidden">
                                            <div className="field-items">
                                              <div className="field-item"><a href="/obio" className="hero-link-dark-bg" style={{backgroundColor: '#000000', borderColor: 'white', color: 'white'}}>Schedule Now</a></div>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div></div>
                            </section>
                          </div>
                        </div>
                      </div>
                      <div className="row">
                        <div className="small-12 columns">
                          <div className="block-region-middle"><section className="views-element-container block-plugin-id-views-block" data-block-plugin-id="views_block:obio_topics-block_1">
                              <div><div className="view view-obio-topics view-id-obio_topics view-display-id-block_1 js-view-dom-id-b087244dacd46395eea19eb480c4db25969fe18edb0da03dc6ccebce8489d559">
                                  <div className="view-content">
                                    <div>
                                      <ul className="row medium-unstack">
                                        <li className="columns"><div className="views-field views-field-nothing"><span className="field-content"><div className="topic-wrapper"><div className="topic-image">  <img src={Casual} width={400} height={400} alt="Thumbnail" typeof="Image" />
                                                </div><div className="topic-link"><a href="/explore/casual-office"><p>Casual Office</p>
                                                  </a></div></div></span></div></li>
                                        <li className="columns"><div className="views-field views-field-nothing"><span className="field-content"><div className="topic-wrapper"><div className="topic-image">  <img src={Downtown} width={400} height={400} alt="Thumbnail" typeof="Image" />
                                                </div><div className="topic-link"><a href="/explore/downtown-style"><p>Downtown Style</p>
                                                  </a></div></div></span></div></li>
                                        <li className="columns"><div className="views-field views-field-nothing"><span className="field-content"><div className="topic-wrapper"><div className="topic-image">  <img src={Echo} width={400} height={400} alt="Thumbnail" typeof="Image" />
                                                </div><div className="topic-link"><a href="/explore/eco-friendly"><p>Eco-Friendly</p>
                                                  </a></div></div></span></div></li>
                                      </ul>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </section>
                          </div>
                        </div>
                      </div>
                      <div className="row full-block-spacing">
                        <div className="small-12 medium-3 columns">
                        </div>
                        <div className="columns">
                        </div>
                      </div>
                      <div className="row full-block-spacing">
                        <div className="columns">
                        </div>
                        <div className="small-12 medium-3 columns">
                        </div>
                      </div>
                      <div className="row">
                        <div className="small-12 columns">
                        </div>
                      </div>
                    </div>
                  </div>
                </article>
              </section>
            </div>
          </section>
        </main>
        <div id="sidebar-second" className="large-3 columns sidebar">
        </div>
      </div>
		);
	}
}
export default WalHome;