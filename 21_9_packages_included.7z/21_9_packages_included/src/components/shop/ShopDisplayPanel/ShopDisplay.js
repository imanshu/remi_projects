 import React,{PropTypes} from 'react';
 import {Link} from 'react-router';
  const ShopDisplay=({shopDetail})=>{
  	const DrupalHost='https://mepclouddemoqu478vdavx.devcloud.acquia-sites.com';
 	return(
 <div className="product-grid-column views-col col-1">
    <div className="views-field views-field-field-category-image">
        <div className="field-content">
            <a href="/shop/category/116"> <img src={DrupalHost+shopDetail.field_category_image} width={294} height={171} alt={shopDetail.name} typeof="foaf:Image" />
            </a>
        </div>
    </div>
    <div className="views-field views-field-name"><span className="field-content"><a href="/shop/category/116">{shopDetail.name}</a></span>
    </div>
</div>
 		);
 }

 export default ShopDisplay;