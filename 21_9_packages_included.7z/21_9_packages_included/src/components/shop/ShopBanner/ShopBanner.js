 import React,{PropTypes} from 'react';
 import {Link} from 'react-router';
  const ShopBanner=()=>{
  	const DrupalHost='https://mepclouddemoqu478vdavx.devcloud.acquia-sites.com';
 	return(
 <section id="block-shopbanner" data-block-plugin-id="block_content:883e8ccc-5611-41b7-81f7-751c0427247e" className="block-shopbanner block-content-type-media block-plugin-id-block-content block-content block-content__media block-content__media--full">
        <div className="hero-block block-content__content block-content__content--media block-content__content--media--full">
          <div className="field-wrapper field field-block-content--field-media field-name-field-media field-type-entity-reference field-label-hidden">
            <div className="field-items">
              <div className="field-item">
                <div className="media media-image view-mode-embedded">
                  <div className="field-wrapper field field-media--image field-name-image field-type-image field-label-hidden">
                    <div className="field-items">
                      <div className="field-item"> <img src={DrupalHost+"/sites/default/files/5x.jpg"} width={1047} height={606} alt typeof="foaf:Image" />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
 		);
 }

 export default ShopBanner;