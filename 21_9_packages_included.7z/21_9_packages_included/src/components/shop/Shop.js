
import React,{PropTypes} from 'react';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';

import * as shopActions from '../../actions/shopActions';
import ShopDisplayList from './ShopDisplayPanel/ShopDisplayList';
import ShopLinksPanel from './ShopLinksPanel/ShopLinksPanel';
import ShopBanner from './ShopBanner/ShopBanner.js';
class shopCategories extends React.Component{
		constructor(props,context){
		super(props,context);
		this.state={
			shopCategories:[]
		};
	}

	render(){
		const {shopCategories}=this.props;
		return(
		<div className="row main-wrap align-center">
        <main id="main" className="shop columns" role="main">
          <a id="main-content" />
           <section>
            <div className="region region-content">
            	<ShopBanner />
            	<ShopDisplayList shopList={shopCategories} />
            </div>
           </section>
		</main>
         <div id="sidebar-second" className="large-3 columns sidebar">
         	<ShopLinksPanel shopLinks={shopCategories} />
         </div>
         </div>
			);
	}

}
function mapStateToProps(state,ownProps)
{
	return{
		shopCategories:state.shopCategories
	};
}
function mapDispatchToProps(dispatch){
	return{
		actions: bindActionCreators(shopActions,dispatch)
	};
}
export default connect(mapStateToProps,mapDispatchToProps)(shopCategories);
