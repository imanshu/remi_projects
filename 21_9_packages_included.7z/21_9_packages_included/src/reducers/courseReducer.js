import initialState from './initialState';
export default function courseReducer(state=initialState.courses,action){
	
	switch(action.type)
	{
		case 'CREATE_COURSE_SUCCESS':
		return [...state,Object.assign({},action.course)];
		case 'DELETE_COURSE_SUCCESS':
		return [...state.filter(course=>course.id !== action.course.id)];
		case 'UPDATE_COURSE_SUCCESS':
		return [...state.filter(course=>course.id !== action.course.id),Object.assign({},action.course)];
		default:
		return state;
		case 'LOAD_COURSES_ON_SUCCESS':
		return action.courses;
	}
	
}