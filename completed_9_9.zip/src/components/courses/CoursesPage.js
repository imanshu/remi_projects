import React,{PropTypes} from 'react';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
//import CourseComp from './courseComp/CourseComp';
import CourseList from './courseList';
import {browserHistory} from 'react-router';
import * as courseActions from '../../actions/courseActions';
class CoursesPage extends React.Component{
	constructor(props,context){
		super(props,context);
		this.state={
			course:{title:null}
		};

		this.deleteFromStore=this.deleteFromStore.bind(this);
		this.updateStore=this.updateStore.bind(this);
		this.redirectToManageCourse=this.redirectToManageCourse.bind(this);
	}

	deleteFromStore(event){
		let key=event.target.getAttribute('data-key');
		console.log(key);
		this.props.actions.deleteCourse(key);
	}
	updateStore(key,course){
		
		this.props.actions.updateCourse(key,course);
	}
	
	redirectToManageCourse(){     
		browserHistory.push('/course/addNew'); 
	} 
/*
courseRow(course,index){
		
		return <CourseComp key={index} idx={index} course={course} initialBtnVal="EDIT" deleteAction={this.deleteFromStore} updateAction={this.updateStore} />;

	}*/
	render(){
		const {courses}=this.props;
		return (
				<div>
					<h1>Courses</h1>
					<input type='submit' 
						value='Add Courses' 
						className='btn btn-primary' 
						onClick={this.redirectToManageCourse} />
					<CourseList courses={courses} />
					<div className='addCoursePanel'>
					
					</div>
  
				</div>
			);
	}
}

CoursesPage.propTypes={
	
	courses:PropTypes.array.isRequired,
	actions:PropTypes.object.isRequired
};
function mapStateToProps(state,ownProps)
{
	return{
		courses:state.courses
	};
}
function mapDispatchToProps(dispatch){
	return{
		actions: bindActionCreators(courseActions,dispatch)
	};
}
export default connect(mapStateToProps,mapDispatchToProps)(CoursesPage);