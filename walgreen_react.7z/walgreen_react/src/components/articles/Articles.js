import React,{PropTypes} from 'react';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import Article from './article';
import * as articleActions from '../../actions/articleActions';
class Articles extends React.Component{
	constructor(props,context){
		super(props,context);
		this.state={
			articles:[]
		};


	}

	render(){
		const {articles}=this.props;
		return (
      <section className="views-element-container block-plugin-id-views-block" data-block-plugin-id="views_block:latest_articles-block_1">
        <h2 className="block-title">Latest Articles</h2>
        <div><div className="latest-articles view view-latest-articles view-id-latest_articles view-display-id-block_1 js-view-dom-id-4c0c06c76027de4792637e00d4711c0e3ac9aeda70f02dc239d45c5dd47d29a4">
            <div className="view-content">
              <div className="dfs-block-grid">
                <ul className="row small-up-1 medium-up-2 large-up-3">
                	{
                		articles.map((article)=>
                		<Article key={article.nid[0].value} articleData={article}/>)
                	}
                </ul>
                </div>
                </div>
               </div>
              </div>
           </section>
			);
	}

}

function mapStateToProps(state,ownProps)
{
	return{
		articles:state.articles
	};
}
function mapDispatchToProps(dispatch){
	return{
		actions: bindActionCreators(articleActions,dispatch)
	};
}
export default connect(mapStateToProps,mapDispatchToProps)(Articles);