 import React,{PropTypes} from 'react';
 const Article=({articleData})=>{
 	return(
 		 <li className="columns">
                                          <article data-history-node-id={171} role="article" about="/content/health-article" typeof="schema:Article" className="node node--type-article node--promoted node--view-mode-card l-card-elem">
                                            <div className="card">
                                              <div className="card__media">
                                                <div className="image field field-node--field-image field-name-field-image field-type-image field-label-visually_hidden">
                                                  <div className="field-label visually-hidden">Image</div>
                                                  <div className="field-items">
                                                    <div className="field-item">  <a href="/content/health-article">  <img property="schema:image" srcSet="/sites/default/files/styles/card_small/public/Walking%20the%20Dogs.jpg?itok=YOMY4jdU 550w, /sites/default/files/styles/card_narrow/public/Walking%20the%20Dogs.jpg?itok=azbbFEWa 612w" sizes=" (min-width: 1140px) 540px, (min-width: 1024px) 49vw,  (min-width: 639px) 98vw, 100vw" src="/sites/default/files/styles/card_narrow/public/Walking%20the%20Dogs.jpg?itok=azbbFEWa" alt={articleData.field_image[0].alt} typeof="foaf:Image" />
                                                      </a>
                                                    </div>
                                                  </div>
                                                </div>
                                              </div>    
                                              <div className="view-mode-card card__content-wrapper">
                                                <div className="card__content">
                                                  <h2 className="node-title card__title">
                                                    <a href="/content/health-article" rel="bookmark"><span property="schema:name" className="field-wrapper">{articleData.title[0].value}</span>
                                                    </a>
                                                  </h2>
                                                  <span property="schema:name" content="Health Article" className="hidden" />
                                                  <span property="schema:interactionCount" content="UserComments:0" className="hidden" />
                                                  <div className="field-wrapper field field-node--field-article-subtitle field-name-field-article-subtitle field-type-string field-label-visually_hidden">
                                                    <div className="field-label visually-hidden">Subtitle</div>
                                                    <div className="field-items">
                                                      <div className="field-item">subtitle</div>
                                                    </div>
                                                  </div>
                                                </div>
                                              </div>
                                            </div>
                                          </article>
                                        </li>
 		);
 }
export default Article;