package com.spring.batch.steps;

import org.springframework.batch.item.ItemReader;

public class DataReader implements ItemReader<String>{
	
	private String message = "welcome to India";
	
	@Override
	public String read() {
		System.out.println("DATA IS READ: " + message );
		return message;
	}

}
