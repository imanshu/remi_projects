package com.java.security.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.java.security.domain.User;

public interface UserRepository extends JpaRepository<User, String> {

	public User findByUserName(String userName);


}
