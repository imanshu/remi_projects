package com.java.security;

import java.util.List;
import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.java.security.config.CustomerUserDetail;
import com.java.security.domain.Role;
import com.java.security.domain.User;
import com.java.security.repository.UserRepository;
import com.java.security.service.UserService;

@SpringBootApplication
public class SecurityApplication implements CommandLineRunner{
	private Logger log = LoggerFactory.getLogger(this.getClass().getName());
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	@Autowired
	UserRepository repository;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SpringApplication.run(SecurityApplication.class, args);
		
	}

	
	@Autowired
	public void authenticationManager(AuthenticationManagerBuilder builder, UserRepository repository, UserService service) throws Exception {
	    service.save(new User("user", "password",Arrays.asList(new Role("user"),new Role("admin"))));
		System.out.println("get:" + repository.findAll());
		builder.userDetailsService(userDetailsService(repository)).passwordEncoder(passwordEncoder);
	}
	
	public UserDetailsService userDetailsService(final UserRepository repository) {
		return name -> new CustomerUserDetail(repository.findByUserName(name));
	}


	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		log.info("get:" + repository.findAll().toString());
		
	}
	
}
