package com.java.security.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SecurityController {
	
	@RequestMapping(value = "/" )
	public String helloController() {
		
		return "hello";
	}
	
	@RequestMapping(value = "/private" )
	public String securityController() {
		
		return "welcome";
	}

}
