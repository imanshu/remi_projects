module.exports = function(grunt) {
  // Project configuration.
  grunt.initConfig({
    pkg: grunt.file.readJSON('package.json'),
    requirejs: {
      check : {
            options: {
                generateSourceMaps : true,
                preserveLicenseComments : false,
                optimize : "uglify2",
                baseUrl: "../",
                name : "apps/check/index",
                out: "../apps/check/app-built.js",
                paths: {
                  'jquery' : 'empty:',
                  'backbone'  : 'empty:',
                  'lodash' : 'empty:',
                  'handlebars' : 'empty:',
                  'bootstrap' : 'empty:',
                  'apps/common/util/ajax-helper' : 'empty:',
                  'apps/common/util/validator' : 'empty:'
                }
            }
        },
        library : {
            options: {
                generateSourceMaps : true,
                preserveLicenseComments : false,
                optimize : "uglify2",
                baseUrl: "../",
                mainConfigFile: "../main.js",
                name : "main",
                out: "../libs-built.js"
            }
        },
        storagenet : {
          options: {
                generateSourceMaps : true,
                preserveLicenseComments : false,
                optimize : "uglify2",
                baseUrl: "../",
                name : "apps/storagenet/initialize",
                out: "../apps/storagenet/app-built.js",
                paths: {
                  'jquery' : 'empty:',
                  'backbone'  : 'empty:',
                  'lodash' : 'empty:',
                  'handlebars' : 'empty:',
                  'bootstrap' : 'empty:',
                  'apps/common/util/ajax-helper' : 'empty:',
                  'apps/common/util/validator' : 'empty:'
                }
            }
        },
        agronet : {
          options: {
                generateSourceMaps : true,
                preserveLicenseComments : false,
                optimize : "uglify2",
                baseUrl: "../",
                name : "apps/agronet/initialize",
                out: "../apps/agronet/app-built.js",
                paths: {
                  'jquery' : 'empty:',
                  'backbone'  : 'empty:',
                  'lodash' : 'empty:',
                  'handlebars' : 'empty:',
                  'bootstrap' : 'empty:',
                  'apps/common/util/ajax-helper' : 'empty:',
                  'apps/common/util/validator' : 'empty:'
                }
            }
        },
        pesticideTracking : {
          options: {
                generateSourceMaps : true,
                preserveLicenseComments : false,
                optimize : "uglify2",
                baseUrl: "../",
                name : "apps/pesticide_tracking/initialize",
                out: "../apps/pesticide_tracking/app-built.js",
                paths: {
                  'jquery' : 'empty:',
                  'backbone'  : 'empty:',
                  'lodash' : 'empty:',
                  'handlebars' : 'empty:',
                  'bootstrap' : 'empty:',
                  'apps/common/util/ajax-helper' : 'empty:',
                  'apps/common/util/validator' : 'empty:'
                }
            }
        },
		  potatoprotection : {
          options: {
                generateSourceMaps : true,
                preserveLicenseComments : false,
                optimize : "uglify2",
                baseUrl: "../",
                name : "apps/potatoprotection/*.js",
                out: "../apps/potatoprotection/app-built.js",
                paths: {
                  'jquery' : 'empty:',
                  'backbone'  : 'empty:',
                  'lodash' : 'empty:',
                  'handlebars' : 'empty:',
                  'bootstrap' : 'empty:',
                  'apps/common/util/ajax-helper' : 'empty:',
                  'apps/common/util/validator' : 'empty:'
                }
            }
        },
        userSettings : {
          options: {
                generateSourceMaps : true,
                preserveLicenseComments : false,
                optimize : "uglify2",
                baseUrl: "../",
                name : "apps/user_settings/initialize",
                out: "../apps/user_settings/app-built.js",
                paths: {
                  'jquery' : 'empty:',
                  'backbone'  : 'empty:',
                  'lodash' : 'empty:',
                  'handlebars' : 'empty:',
                  'bootstrap' : 'empty:',
                  'apps/common/util/ajax-helper' : 'empty:',
                  'apps/common/util/validator' : 'empty:'
                }
            }
        }
    },
    cssmin: {
        combine: {
            files: {
              '../../css/build/dist/combined.min.css': ['../../css/libs/bootstrap/bootstrap.min.css',
                                         '../../css/libs/bootstrap/datepicker.css',
                                         '../../css/apps/theme/_sprites.css',
                                         '../../css/apps/theme/bootstrap.theme.css',
                                         '../../css/apps/theme/homepage.css',
                                         '../../css/apps/fritoforum/fritoforum.css',
                                         '../../css/apps/theme/static-page.css',
                                         '../../css/apps/storagenet/field-data.css',
                                         '../../css/apps/storagenet/data-map.css',
                                         '../../css/apps/mgmt_system/management-system.css',
                                         '../../css/libs/bootstrap/common.css']
            }
        }
    },
	uglify: {
      options: {
        banner: '/*! <%= pkg.name %> <%= grunt.template.today("yyyy-mm-dd") %> */\n'
      },
      build: {
        src: '../apps/potatoprotection/views/*.js',
        dest: '../apps/potatoprotection/app-built.js'
      }
    }
  });

  //define packages
  grunt.loadNpmTasks('grunt-contrib-requirejs');
  grunt.loadNpmTasks('grunt-contrib-cssmin');
  grunt.loadNpmTasks('grunt-contrib-uglify');

  // Default task(s).
  grunt.registerTask('default', ['requirejs:check','requirejs:library',
                                 'requirejs:storagenet',
                                 'requirejs:agronet',
                                 'requirejs:pesticideTracking',
                                 'requirejs:userSettings',
                                 'cssmin','uglify']);
};