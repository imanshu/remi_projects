define([
  
  'backbone',
  'apps/common/app',
  'jquery'
  ], function( Backbone, app,$){
var potatoProtect=function(){
   this.initialize=function(){
     $.ajax({url: "<%=varietyUrl%>?fetch=varietyinfo&countryId=0", success: function(result){    
if (result.content.values.length == 0) {
                    $('.variety-list-tbl tbody').append("<tr><td colspan='5'><p>No data available<p></td></tr>");
          $('.loader-overlay').hide();
                } else{  
        result.content.values.forEach(function (data, i) {
        var ed = '';
            var varietyId = data["varId"];
                var comDate = data["firstSaleDate"];
                var reqDate = comDate ? comDate.slice(0, 12) : "";
                var varnameData = data["varName"] == undefined ? "" : data["varName"];
                var countryName = data["cntryName"] == undefined ? "" : data["cntryName"];
                var commentsData = data["comments"] == undefined ? "" : data["comments"];
                $('.variety-list-tbl tbody').append("<tr><td><a value='"+varietyId+"' href=''>" + varnameData + "</a></td><td>" + reqDate + "</td><td>" + countryName + "</td><td>" + commentsData + "</td></tr>");
        $('.loader-overlay').hide();
    });
        }
}});
$('.loader-overlay').show();
 $.ajax({url: "<%=countryUrl%>?fetch=country", success: function(result){      
        result.content.values.forEach(function(data){        
         $('#select-country-drpdwn').append('<option value="' + data["id"] + '">' + data["name"] + '</option>');
     $('.loader-overlay').hide();
});

}});

$('.variety-list-tbl').stupidtable();

$("#select-country-drpdwn").change(function () {
   $('.loader-overlay').show();
        var selectedValue = $(this).val()
         loadCountryData(selectedValue);
          $('.variety-list-tbl tbody').html('');
    }) 
    
    function loadCountryData(selectedValue) {
        $.ajax({
            url: "<%=varietyCountryUrl%>?fetch=varietyinfo&countryId="+selectedValue,success: function (result) {
        if (result.content.values.length == 0) {
                    $('.variety-list-tbl tbody').append("<tr><td colspan='5'><p>No data available for this country<p></td></tr>");
          $('.loader-overlay').hide();
                } else{  
                result.content.values.forEach(function (data, i) {
                var ed = '';
                  var varietyId = data["varId"];
                    var comDate = data["firstSaleDate"];
                    var reqDate = comDate ? comDate.slice(0, 12) : "";
                    var varnameData = data["varName"] == undefined ? "" : data["varName"];
                    var countryName = data["cntryName"] == undefined ? "" : data["cntryName"];
                    var commentsData = data["comments"] == undefined ? "" : data["comments"];
                    $('.variety-list-tbl tbody').append("<tr><td><a value='" +varietyId+ "' href=\'" +ed+ "'>" + varnameData + "</a></td><td>" + reqDate + "</td><td>" + countryName + "</td><td>" + commentsData + "</td></tr>");
          $('.loader-overlay').hide();
                });
        }
            }
        });
    } 
  }
}

  return potatoProtect;
});