import React,{PropTypes} from 'react';
import {Route,IndexRoute} from 'react-router';

import HomePage from './components/home/WalHome';
import WalgreenApp from './components/walgreensApp.js';
import ShopPage from './components/shop/Shop';
import ShopMajorityPage from './components/shop/ShopMajorCategories';
import ProductDetailPage from './components/shop/Product/ProductDetails';
export default (
/*	<Route path="/" component={App}>
		<IndexRoute component={HomePage} />
		<Route path='about' component={AboutPage} />
		<Route path='courses' component={CoursesPage} />
		<Route path='course/:id' component={ManageCoursePage} />
		
	</Route>*/
	<Route path="/" component={WalgreenApp} >
		<IndexRoute component={HomePage} />
		
		<Route path='shop' component={ShopPage} >
			<IndexRoute component={ShopMajorityPage} />
			<Route path='category/:id' component={ProductDetailPage} />
		</Route>

		
	</Route>
);