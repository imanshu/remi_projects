import * as types from './actionTypes';

import axios from 'axios';
export function loadShopCategoriesOnSuccess(shopCategories){
	return {type:types.LOAD_SHOPCATEGORIES_ON_SUCCESS,shopCategories}
}
export function loadShopSubCategoriesOnSuccess(shopSubCategories){
	return {type:types.LOAD_SHOPSUBCATEGORIES_ON_SUCCESS,shopSubCategories}
}
export function loadProductDetailsOnSuccess(productDetails){
	return {type:types.LOAD_PRODUCTDETAILS_ON_SUCCESS,productDetails}
}
export function loadShopBannerOnSuccess(shopBanner){
	return {type:types.LOAD_SHOPBANNER_ON_SUCCESS,shopBanner}
}
export function loadShopCategories(){
	return function(dispatch){
		
		return axios.get(`https://mepclouddemoqu478vdavx.devcloud.acquia-sites.com/shop/category/export/major`)
				.then(shopCategories=>{
					console.log(shopCategories.data);
					dispatch(loadShopCategoriesOnSuccess(shopCategories.data));
				})
				.catch(error=>{
					throw(error);
				})
	};
}
export function loadShopSubCategories(){
	return function(dispatch){
		
		return axios.get(`https://mepclouddemoqu478vdavx.devcloud.acquia-sites.com/shop/category/export/all`)
				.then(shopSubCategories=>{
					console.log(shopSubCategories.data);
					dispatch(loadShopSubCategoriesOnSuccess(shopSubCategories.data));
				})
				.catch(error=>{
					throw(error);
				})
	};
}

export function loadProductDetails(ide){
	return function(dispatch){
			
		return axios.get(`https://mepclouddemoqu478vdavx.devcloud.acquia-sites.com/shop/category/export/`+ide)
				.then(productDetails=>{
					console.log('productdeatails are',productDetails.data);
					dispatch(loadProductDetailsOnSuccess(productDetails.data));
				})
				.catch(error=>{
					throw(error);
				})
	};
}

export function loadShopBanner(){
	return function(dispatch){
		
		return axios.get(`https://mepclouddemoqu478vdavx.devcloud.acquia-sites.com/shop/banner/export`)
				.then(shopBanner=>{
					console.log(shopBanner.data);
					dispatch(loadShopBannerOnSuccess(shopBanner.data));
				})
				.catch(error=>{
					throw(error);
				})
	};
}