import * as types from './actionTypes';

import axios from 'axios';

export function loadArticlesOnSuccess(articles){
	return {type:types.LOAD_ARTICLES_ON_SUCCESS,articles}
}
export function loadArticles(){
	return function(dispatch){
		
		return axios.get(`https://mepclouddemoqu478vdavx.devcloud.acquia-sites.com/rest/latest-articles`)
				.then(articles=>{
					console.log(articles.data);
					dispatch(loadArticlesOnSuccess(articles.data));
				})
				.catch(error=>{
					throw(error);
				})
	};
}

