 import React,{PropTypes} from 'react';
 import {Link,IndexLink} from 'react-router';


 const Header=()=>{
  const DrupalHost='https://mepclouddemoqu478vdavx.devcloud.acquia-sites.com';
 	return(
 	<div className="header-wrap">
        <div className="row align-center">
          <div className="header-left columns">
            <div className="region region-header align-middle">
              <section id="block-sitebranding" className="columns shrink hide-for-small-only align-middle obio-logo block-sitebranding block-plugin-id-system-branding-block" data-block-plugin-id="system_branding_block">
                <div>
                  <IndexLink to="/" activeclassName="active" title="Home" rel="home" />
                  <img src={DrupalHost+'/sites/default/files/Walgreens_1.png'} alt="Home" />
                </div>
              </section>
              <nav role="navigation" aria-labelledby="block-mainnavigation-menu" id="block-mainnavigation" className="columns align-middle block-mainnavigation block-plugin-id-system-menu-block" data-block-plugin-id="system_menu_block:main">
                <h2 className="block-title visually-hidden" id="block-mainnavigation-menu">Main navigation</h2>
                <div className="top-bar-wrapper">
                  <div className="row column">
                    <div className="title-bar" data-responsive-toggle="main-menu" data-hide-for="medium" style={{display: 'none'}}>
                      <button className="menu-icon columns align-right small-1" type="button" data-toggle />
                      <div className="small-logo align-center small-4">
                        <span className="small-text-logo">
                          <IndexLink to="/" activeclassName="active" title="Obio Home">Obio</IndexLink>
                        </span>
                      </div>
                    </div>
                    <nav className="header-bar" id="main-menu" role="navigation">
                      <div className="top-bar-left">
                        <ul className="menu topbar-toplevel dropdown" data-responsive-menu="drilldown medium-dropdown" id="findd" role="menubar" data-dropdown-menu="rhwqmm-dropdown-menu" data-mutate="rymqrm-responsive-menu">
                          <li role="menuitem">
                            <a href="/rx-refills" data-drupal-Link-system-path="node/146">Rx Refills</a>
                          </li>
                          <li role="menuitem">
                            <a href="/health-info-services" data-drupal-Link-system-path="node/151">Health Info &amp; Services</a>
                          </li>
                          <li role="menuitem">
                            <a href="/beauty" data-drupal-Link-system-path="node/156">Beauty</a>
                          </li>
                          <li role="menuitem">
                            <a href="/mp1" data-drupal-Link-system-path="node/191">MP1</a>
                          </li>
                          <li role="menuitem">
                            <a href="/shop" data-drupal-Link-system-path="shop">Shop</a>
                          </li>
                        </ul>
                      </div>
                      <div className="top-bar-right">
                      </div>
                    </nav>
                  </div>
                </div>
              </nav>
            </div>
          </div>
          <div className="header-right columns">
            <div className="region region-header-right">
              <section id="block-userdropdown" data-block-plugin-id="user_dropdown" className="block-userdropdown block-plugin-id-user-dropdown">
                <a className="login-dropdown-button standard-icon meta-icon-size left" data-toggle="user-login-wrapper" aria-controls="user-login-wrapper" aria-expanded="false" data-is-focus="false" data-yeti-box="user-login-wrapper" aria-haspopup="true"><i className="icon ion-ios-person"><span>Login</span></i></a><div className="dropdown-pane display-none" id="user-login-wrapper" data-dropdown="iw790u-dropdown" aria-hidden="true" aria-autoclose="true" data-auto-focus="true" tabIndex={-1} data-yeti-box="user-login-wrapper" data-resize="user-login-wrapper" aria-labelledby="prav8v-dd-anchor">
                  <form className="user-login-form obio-form form__id-user-login-form" data-drupal-selector="user-login-form" action="/" method="post" id="user-login-form" acceptCharset="UTF-8">
                    <div className="js-form-item form-item js-form-type-textfield form-item-name js-form-item-name">
                      <label htmlFor="edit-name" className="form-required">Username</label>
                      <input autoCorrect="none" autoCapitalize="none" spellCheck="false" autoFocus="autoFocus" data-drupal-selector="edit-name" type="text" id="edit-name" name="name" defaultValue size={60} maxLength={60} className="form-text required" required="required" aria-required="true" />
                    </div>
                    <div className="js-form-item form-item js-form-type-password form-item-pass js-form-item-pass">
                      <label htmlFor="edit-pass" className="form-required">Password</label>
                      <input data-drupal-selector="edit-pass" type="password" id="edit-pass" name="pass" size={60} maxLength={128} className="form-text required" required="required" aria-required="true" />
                    </div>
                    <input data-drupal-selector="form-c8t9ntfb5oiygfyqvgwhch0nhc7exgtpdf8tyx-wcok" type="hidden" name="form_build_id" defaultValue="form-C8T9ntfB5OIygfyQVgWhcH0nHc7exgTPDF8tYX_WCok" />
                    <input data-drupal-selector="edit-user-login-form" type="hidden" name="form_id" defaultValue="user_login_form" />
                    <div data-drupal-selector="edit-actions" className="form-actions js-form-wrapper form-wrapper" id="edit-actions"><input className="success button radius js-form-submit form-submit" data-drupal-selector="edit-submit" type="submit" id="edit-submit" name="op" defaultValue="Log in" />
                    </div>
                  </form>
                </div>
              </section>
              <section id="block-cart" data-block-plugin-id="commerce_cart" className="block-cart block-plugin-id-commerce-cart">
                <div className="cart--cart-block">
                  <div className="cart-block--summary">
                    <a className="cart-block--Link__expand" href="/cart">
                      <span className="cart-block--summary__icon"><span className="meta-icon-size"><i className="icon ion-ios-cart" /></span></span>
                      <span className="cart-block--summary__count">Cart</span>
                    </a>
                  </div>
                </div>
              </section>
            </div>
          </div>
        </div>
      </div>













 		);
};
 export default Header;
