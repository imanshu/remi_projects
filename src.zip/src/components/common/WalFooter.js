 import React,{PropTypes} from 'react';
 import {Link,IndexLink} from 'react-router';
 const WalFooter=()=>{
 	return(
 		      <footer id="footer" className="dark-bg full-width-row">
        <div className="full-width-inner align-center">
          <div className="row" id="bottom-area">
            <div id="footer-first" className="columns small-12 medium-3">
              <div className="region region-footer-first">
                <nav role="navigation" aria-labelledby="block-footer-menu" id="block-footer" data-block-plugin-id="system_menu_block:footer" className="block-footer block-plugin-id-system-menu-block">
                  <h2 className="block-title visually-hidden" id="block-footer-menu">Footer</h2>
                  <ul className="menu">
                    <li>
                      <a href="/contact" data-drupal-link-system-path="contact">Contact</a>
                    </li>
                    <li>
                      <a href="/shop/office" title="Shop Office" data-drupal-link-system-path="node/16">Shop Office</a>
                    </li>
                    <li>
                      <a href="/about" title="About" data-drupal-link-system-path="node/21">About</a>
                    </li>
                    <li>
                      <a href="/inspiration" title="Inspiration" data-drupal-link-system-path="node/6">Inspiration</a>
                    </li>
                    <li>
                      <a href="/locations" title="Locations" data-drupal-link-system-path="node/11">Locations</a>
                    </li>
                  </ul>
                </nav>
              </div>
            </div>
            <div id="footer-middle" className="columns small-12 medium-6">
              <div className="region region-footer-middle">
                <section id="block-subscribeform" data-block-plugin-id="subscribe_form" className="block-subscribeform block-plugin-id-subscribe-form">
                  <h2 className="block-title">Subscribe &amp; Save</h2>
                  <form data-drupal-selector="dfs-obio-subscribe-form" className="obio-form form__id-dfs-obio-subscribe-form" action="/" method="post" id="dfs-obio-subscribe-form" acceptCharset="UTF-8">
                    <div className="row js-form-wrapper form-wrapper" data-drupal-selector="edit-form" id="edit-form"><div className="columns medium-9 small-12"><div className="js-form-item form-item js-form-type-textfield form-item-email js-form-item-email form-no-label">
                          <input className="email-form-textbox form-text required" placeholder="Enter Email Address" data-drupal-selector="edit-email" type="text" id="edit-email" name="email" defaultValue size={80} maxLength={128} required="required" aria-required="true" />
                        </div>
                      </div><div className="columns medium-3 small-12"><input className="subscribe-submit button js-form-submit form-submit" data-drupal-selector="edit-submit" type="submit" id="edit-submit--2" name="op" defaultValue="Sign Up" />
                      </div></div>
                    <input data-drupal-selector="form-lo4cosmgwtb0k08ssyi873gqclwcz7pct-khzzolaha" type="hidden" name="form_build_id" defaultValue="form-lo4COsMGwTb0k08SSYi873GQCLwcz7PcT_kHZZOlAhA" />
                    <input data-drupal-selector="edit-dfs-obio-subscribe-form" type="hidden" name="form_id" defaultValue="dfs_obio_subscribe_form" />
                  </form>
                </section>
              </div>
            </div>
            <div id="footer-last" className="columns small-12 medium-3">
              <div className="region region-footer-last">
                <section className="language-switcher-language-url block-languageswitcher block-plugin-id-language-block" id="block-languageswitcher" role="navigation" data-block-plugin-id="language_block:language_interface">
                  <h2 className="block-title">Language:</h2>
                  <a data-toggle="language-dropdown" className="standard-icon meta-icon-size language-dropdown-button left" aria-controls="language-dropdown" data-is-focus="false" data-yeti-box="language-dropdown" aria-haspopup="true" aria-expanded="false"><i className="icon ion-earth" /><span className="current-langcode">en</span></a><div className="dropdown-pane top language-pane display-none" id="language-dropdown" data-dropdown="jwjf5l-dropdown" data-auto-focus="true" aria-hidden="true" data-yeti-box="language-dropdown" data-resize="language-dropdown" aria-labelledby="zgxswh-dd-anchor"><ul className="links"><li hrefLang="en" data-drupal-link-system-path="node/1" className="en is-active"><a href="/obio" className="language-link is-active" hrefLang="en" data-drupal-link-system-path="node/1">English</a></li><li hrefLang="fr" data-drupal-link-system-path="node/1" className="fr"><a href="/fr/obio" className="language-link" hrefLang="fr" data-drupal-link-system-path="node/1">Français</a></li><li hrefLang="es" data-drupal-link-system-path="node/1" className="es"><a href="/es/obio" className="language-link" hrefLang="es" data-drupal-link-system-path="node/1">Español</a></li></ul></div>
                </section>
              </div>
            </div>        </div>
        </div>
      </footer>
 		);
 }
 export default WalFooter;