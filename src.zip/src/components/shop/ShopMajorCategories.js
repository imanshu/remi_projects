 import React,{PropTypes} from 'react';
 import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
 import {Link} from 'react-router';
import * as shopActions from '../../actions/shopActions';
import ShopDisplayList from './ShopDisplayPanel/ShopDisplayList';
import ShopLinksPanel from './ShopLinksPanel/ShopLinksPanel';
import ShopBanner from './ShopBanner/ShopBanner.js';
class ShopMajorCategories extends React.Component{
	constructor(props,context){
		super(props,context);
		this.state={
			shopCategories:[]
		};
	}
  	render(){
  		const {shopCategories,shopBanner}=this.props;
  		  	return(
            <div className="region region-content">
            	<ShopBanner shopBannerUrl={shopBanner[0].image.split('src=')[1].split('"')[1]} />
            	<ShopLinksPanel shopLinks={shopCategories} />
            	<ShopDisplayList shopList={shopCategories} />
            	
            </div>
  		);
  	}

  }

function mapStateToProps(state,ownProps)
{
	return{
		shopCategories:state.shopMajorCategories,
		shopBanner:state.shopBanner
	};
}
function mapDispatchToProps(dispatch){
	return{
		actions: bindActionCreators(shopActions,dispatch)
	};
}
export default connect(mapStateToProps,mapDispatchToProps)(ShopMajorCategories);

