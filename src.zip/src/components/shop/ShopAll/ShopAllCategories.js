 import React,{PropTypes} from 'react';
 import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
 import {Link} from 'react-router';
import * as shopActions from '../../../actions/shopActions';

import CategoryDivisions from './CategoryDivisions';
class ShopAllCategories extends React.Component{
	constructor(props,context){
		super(props,context);
    
		this.state={
			shopAllCategories:[],
      shopMajorCategories:[]
		};
	}


  	render(){
  		const {shopAllCategories,shopMajorCategories}=this.props;
  		  	return(
             <section className="views-element-container block-views-block-all-taxonomy-terms-block-1 block-plugin-id-views-block" id="block-views-block-all-taxonomy-terms-block-1" data-block-plugin-id="views_block:all_taxonomy_terms-block_1">
                
                 <h2 className="block-title">Shop Featured Categories</h2>
        
          <div className="view view-all-taxonomy-terms view-id-all_taxonomy_terms view-display-id-block_1 js-view-dom-id-dcaf7fd47a57d4088a3e70ed1d3e99e3e887244a5397f6e6b2097fc5ca662e32">
            <div className="view-content">
              
              {shopMajorCategories && shopMajorCategories.map((majCategory,key)=>{
                  
                return (
                <div className='clearfix' key={key}>
                <h3>{majCategory.name}</h3>
                {this.props.shopAllCategories.filter((shopAll)=>{return shopAll.parent_cat_name == majCategory.name;}).map((filterCategory,key)=>{return <CategoryDivisions key={key} subCategory={filterCategory}/>;})} 
                </div>)

              })}

            </div>
          
        </div>
      </section>
  		);
  	}

  }

function mapStateToProps(state,ownProps)
{
	return{
		shopAllCategories:state.shopAllCategories,
    shopMajorCategories:state.shopMajorCategories
	};
}

export default connect(mapStateToProps)(ShopAllCategories);