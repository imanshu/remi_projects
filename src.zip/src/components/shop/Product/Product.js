 import React,{PropTypes} from 'react';
 import {Link} from 'react-router';
  const Product=({productDetail})=>{
 	const DrupalHost='https://mepclouddemoqu478vdavx.devcloud.acquia-sites.com';
 	console.log('The product is ',productDetail);
  	return (
  		 
      <div className="views-col col-1" style={{width: '16.666666666667%'}}>
        <div className="views-field views-field-field-category-image"><div className="field-content"><a href={"/shop/category/"+productDetail.tid}> 
         <img src={DrupalHost+productDetail.field_category_image} width={100} height={100} alt="Cosmetics" typeof="foaf:Image" />
            </a></div></div><div className="views-field views-field-name"><span className="field-content"><a href={"/shop/category/"+productDetail.tid}>{productDetail.name}</a></span></div>
      </div>
  		 
  		);
  }

export default Product;