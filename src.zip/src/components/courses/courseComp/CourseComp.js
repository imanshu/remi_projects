import React,{PropTypes} from 'react';

class CourseComp extends React.Component{
	constructor(props,context){
		super(props,context);
		this.state={
			currCourse:{title:null},
			initialBtnVal:'EDIT'
		};
		this.saveOnChange=this.saveOnChange.bind(this);
		this.updateChange=this.updateChange.bind(this);
		this.initialBtnVal='EDIT';
	}
	saveOnChange(event){
		let currentVal=event.target.value;
		let currCourse={title:currentVal};
		this.setState({currCourse:currCourse,initialBtnVal:'Done'});
	}
	updateChange(event){
		let key=event.target.getAttribute('data-key');
		
		if(this.state.initialBtnVal=='Done')
		{
			this.props.updateAction(key,this.state.currCourse);
			this.setState({initialBtnVal:'EDIT'});
		}
	}
	render(){
		return(
			<div className='courseComp'>
					<input type="text" id="ins" defaultValue={this.props.course.title} onChange={this.saveOnChange} />
					{"         "}
					<input type="button" data-key={this.props.idx} value='Del' onClick={this.props.deleteAction}/>
					<input type="button" data-key={this.props.idx} value={this.state.initialBtnVal} onClick={this.updateChange}/>
				</div>
			);
	}
}
export default CourseComp;