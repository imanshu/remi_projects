import initialState from './initialState';
export default function productDetailReducer(state=[],action){
	
	switch(action.type)
	{


		case 'LOAD_PRODUCTDETAILS_ON_SUCCESS':
		return action.productDetails;
		default:
		return state;

	}
	
}