export default {
	authors:[],
	courses:[]
}