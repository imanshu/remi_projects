import initialState from './initialState';
export default function shopBannerReducer(state=[],action){
	
	switch(action.type)
	{

		case 'LOAD_SHOPBANNER_ON_SUCCESS':
		return action.shopBanner;

		default:
		return state;

	}
	
}