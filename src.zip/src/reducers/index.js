import {combineReducers} from 'redux';
import articles from './articleReducer';
import shopMajorCategories from './shopMajorCategoryReducer';
import shopAllCategories from './shopAllCategoryReducer';
import shopBanner from './shopBannerReducer';
import productDetails from './productDetailReducer';
import ajaxCallsInProgress from './ajaxStatusReducer';
const rootReducer=combineReducers({
	articles,
	shopMajorCategories,
	shopAllCategories,
	ajaxCallsInProgress,
	productDetails,
	shopBanner

});
export default rootReducer;
