import initialState from './initialState';
export default function articleReducer(state=initialState.articles,action){
	
	switch(action.type)
	{

		case 'LOAD_ARTICLES_ON_SUCCESS':
		return action.articles;
		default:
		return state;

	}
	
}