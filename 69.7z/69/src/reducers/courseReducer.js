import initialState from './initialState';
export default function courseReducer(state=initialState.courses,action){
	
	switch(action.type)
	{
		case 'CREATE_COURSE':
		return [...state,Object.assign({},action.course)];
		case 'DELETE_COURSE':
		return Object.keys(state).reduce((result, key)=>{if(key!=Number(action.key)){
			result[key]=state[key];
		}
		return result;
			},[]);
		case 'UPDATE_COURSE':
		return Object.keys(state).reduce((result, key)=>{if(key==Number(action.key)){
			result[key]=state[key];
			result[key]=action.course;
			
		}
		else
		{
			result[key]=state[key];
		}
		return result;
			},[]);
		default:
		return state;
		case 'LOAD_COURSES_ON_SUCCESS':
		return action.courses;
	}
	
}