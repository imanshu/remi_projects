import React from 'react';
class AboutPage extends React.Component{
	render(){
		return (
			<div>
				<h1>About</h1>
				<p>This is a Tutorial sight having plenty of open courses for you</p>
			</div>
		);
	}
}
export default AboutPage;