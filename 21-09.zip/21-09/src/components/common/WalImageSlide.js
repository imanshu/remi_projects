 import React,{PropTypes} from 'react';

 const WalImage=({title})=>{
 	 return (

      <section data-block-plugin-id="block_content:07aedfad-f743-42e9-b3f6-af4d0f8adac2" className="block-content-type-hero block-plugin-id-block-content block-content block-content__hero block-content__hero--full">
        <div className="hero-block block-content__content block-content__content--hero block-content__content--hero--full">
          <div className="full-width-row l-over-each">
            <div className="l-over-each__item l-over-each__nested-img l-over-each__nested-img--hero hero-alignment-left">
              <div className="field-wrapper field field-block-content--field-hero-image field-name-field-hero-image field-type-image field-label-hidden">
                <div className="field-items">
                  <div className="field-item">    <picture>
                      {/*[if IE 9]><video style="display: none;"><![endif]*/}
                      <source srcSet="/sites/default/files/styles/hero_image/public/No7.png?itok=O7tHR17_ 1x, /sites/default/files/styles/hero_image/public/No7.png?itok=O7tHR17_ 2x" media="all and (min-width: 64em)" type="image/png" />
                      <source srcSet="/sites/default/files/styles/hero_square/public/No7.png?itok=jel3QgKI 1x, /sites/default/files/styles/hero_square/public/No7.png?itok=jel3QgKI 2x" media="all and (min-width: 40em)" type="image/png" />
                      <source srcSet="/sites/default/files/styles/hero_mobile/public/No7.png?itok=X-YpHnm7 1x, /sites/default/files/styles/hero_mobile/public/No7.png?itok=X-YpHnm7 2x" media="all and (max-width: 39.9375em)" type="image/png" />
                      {/*[if IE 9]></video><![endif]*/}
                      <img src="/sites/default/files/styles/hero_image/public/No7.png?itok=O7tHR17_" alt typeof="foaf:Image" />
                    </picture>
                  </div>
                </div>
              </div>
            </div>
            <div className="l-over-each__item">
              <div className="full-width-inner align-left">
                <div className="medium-7 large-5 column">
                  <div className="hero-content text-center" style={{background: '#ffffff'}}>
                    <div style={{color: '#000000'}} className="field-wrapper field field-block-content--field-first-line field-name-field-first-line field-type-string field-label-hidden">
                      <div className="field-items">

                        <div className="field-item">{title}</div>

                      </div>
                    </div>
                    <div style={{color: '#000000'}} className="field-wrapper field field-block-content--field-second-line field-name-field-second-line field-type-string field-label-hidden">
                      <div className="field-items">
                        <div className="field-item">Second Line</div>
                      </div>
                    </div>
                    <div className="field-wrapper field field-block-content--field-hero-link field-name-field-hero-link field-type-link field-label-hidden">
                      <div className="field-items">
                        <div className="field-item"><a href="/obio" className="hero-link-dark-bg" style={{backgroundColor: '#000000', borderColor: 'white', color: 'white'}}>Learn More</a></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div></div>
      </section>
    );

 }

 WalImage.propTypes={
 	title:PropTypes.string.isRequired
 }

 export default WalImage;