import {combineReducers} from 'redux';
import courses from './courseReducer';
import authors from './authorReducer';
import articles from './articleReducer';
import ajaxCallsInProgress from './ajaxStatusReducer';
const rootReducer=combineReducers({
	courses,
	authors,
	articles,
	ajaxCallsInProgress

});
export default rootReducer;
