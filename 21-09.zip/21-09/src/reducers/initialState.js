export default {
	authors:[],
	courses:[],
	articles:[],
	ajaxCallsInProgress:0
}