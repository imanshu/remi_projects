import * as types from './actionTypes';
import AuthorApi from '../api/mockAuthorApi';
import {beginAjaxCall} from './ajaxStatusActions';
export function loadAuthorsOnSuccess(authors){
	console.log("iniside action");
	return {type:types.LOAD_AUTHORS_ON_SUCCESS,authors}
}
export function loadAuthors(){
	return function(dispatch){
		dispatch(beginAjaxCall());
		return AuthorApi.getAllAuthors()
				.then(authors=>{
					dispatch(loadAuthorsOnSuccess(authors));
				})
				.catch(error=>{
					throw(error);
				})
	};
}
