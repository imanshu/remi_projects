import React from 'react';
import {render} from 'react-dom';
import { DatePicker } from 'antd';

import 'antd/dist/antd.css';  // or 'antd/dist/antd.less'

class App extends React.Component {
  render () {
    return (<div>

             <p> Hello React!</p>
             <DatePicker />
            </div>);
  }
}

render(<App/>, document.getElementById('app'));