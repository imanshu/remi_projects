/* @flow */

import _ from 'lodash/fp';

import type { FormData, Action } from '../types';

type State = FormData;

const initialState = {
  login: '',
  password: 'test_password',
  email: 'testragu@gmail.com',
  firstName: 'Ragu',
  lastName: 'Sundaram',
  postalCode: '',
  phoneNumber: '',
  addresses: [
    {
      items: {
        type: 'test_homeAddress',
        postalCode: '12345209',
        phoneNumber: '9876543210'
      }
    }
  ],
  otherOptions: {
    mobileApp: 'true',
    activeSubscriptionsAsCSV: 'test_receivePromoAndSpecialEvents'
  }
};

export default (state: State = initialState, action: Action): State => {
  switch (action.type) {
    case 'SUBMIT_REQUESTING':
      return _.assign(state, {
        readyStatus: 'SUBMIT_REQUESTING'
      });
    case 'SUBMIT_FAILURE':
      return _.assign(state, {
        readyStatus: 'SUBMIT_FAILURE',
        err: action.err
      });
    case 'SUBMIT_SUCCESS':
      return _.assign(state, {
        readyStatus: 'SUBMIT_SUCCESS',
        formValues: action.data
      });
    default:
      return state;
  }
};
