/* @flow */

import _ from 'lodash/fp';

import type { RegistrationFormData, Action } from '../types';

type State = RegistrationFormData;

const initialState = {
  readyStatus: 'USERS_INVALID',
  err: null,
  viewInfo: {}
};

export default (state: State = initialState, action: Action): State => {
  console.log(action.type,state);
  switch (action.type) {
    case 'USERS_REQUESTING':
      return _.assign(state, {
        readyStatus: 'USERS_REQUESTING'
      });
    case 'USERS_FAILURE':
      return _.assign(state, {
        readyStatus: 'USERS_FAILURE',
        err: action.err
      });
    case 'USERS_SUCCESS':
      return _.assign(state, {
        readyStatus: 'USERS_SUCCESS',
        viewInfo: action.data
      });
    default:
      return state;
  }
};
