/* @flow */

import React, { PureComponent } from 'react';
import type { Element } from 'react';
import { Grid, Row, Col } from 'react-bootstrap';
import { connect } from 'react-redux';
import type { Connector } from 'react-redux';
import type {
  RegistrationFormData as RegistrationFormDataType,
  Dispatch,
  ReduxState
} from '../../types';
import CreateForm from '../../components/CreateForm';
import * as styles from '../../components/CreateForm/register.scss';
// import logo from '../../components/CreateForm/logo.png';
import * as actionUsers from '../../actions/loadView';

type Props = {
  initalRegistrationFormData: RegistrationFormDataType,
  loadViewForm: () => void
};

// Export this for unit testing more easily
export class CreateAccount extends PureComponent<Props> {
  componentDidMount() {
    this.props.loadViewForm();
  }

  renderCreateForm = (): Element<'p' | typeof CreateForm> => (
    <CreateForm info={this.props.initalRegistrationFormData.viewInfo} />
  );

  render() {
    const { initalRegistrationFormData } = this.props;
    console.log('initalRegistrationFormData', initalRegistrationFormData);

    return (
      <Grid className={styles.registerationPage}>
        <Row className="show-grid">
          <Col xs={12} sm={12} md={12} lg={4}>
            <img alt="AutoZone" src="/ss" className={styles.regLogo} />
            <h1>
              {
                initalRegistrationFormData.viewInfo
                  .mf_registration_createAccount
              }
            </h1>
            <div>{this.renderCreateForm()}</div>
          </Col>
          <Col xsHidden lg={8}>
            Banner Here
          </Col>
        </Row>
      </Grid>
    );
  }
}

const connector: Connector<{}, Props> = connect(
  ({ initalRegistrationFormData }: ReduxState) => ({
    initalRegistrationFormData
  }),
  (dispatch: Dispatch) => ({
    loadViewForm: () => dispatch(actionUsers.loadViewForm())
  })
);

export default connector(CreateAccount);
