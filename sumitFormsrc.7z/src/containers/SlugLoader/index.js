import React, { PureComponent } from 'react';
import { LinkContainer } from 'react-router-bootstrap';
import Navbar from 'react-bootstrap/lib/Navbar';
import Nav from 'react-bootstrap/lib/Nav';
import NavItem from 'react-bootstrap/lib/NavItem';
import NavDropdown from 'react-bootstrap/lib/NavDropdown';
import MenuItem from 'react-bootstrap/lib/MenuItem';
import PropTypes from 'prop-types';

export default class SlugLoader extends PureComponent {
  render() {
    return (
      <Navbar inverse collapseOnSelect>
        <Navbar.Collapse>
          <Nav>
            {this.props.menuNavigation.map(menuNav => (
              <LinkContainer key={menuNav.id} to="/Home/CreateAccount">
                <NavItem eventKey={menuNav.id} href="#">
                  {menuNav.name}
                </NavItem>
              </LinkContainer>
            ))}
            <NavDropdown
              eventKey={3}
              title="Exterior Equipments"
              id="basic-nav-dropdown"
            >
              <MenuItem eventKey={3.1}>Products</MenuItem>
              <MenuItem eventKey={3.2}>Categories</MenuItem>
              <MenuItem eventKey={3.3}>Settings</MenuItem>
              <MenuItem divider />
              <MenuItem eventKey={3.3}>Popular</MenuItem>
            </NavDropdown>
          </Nav>
        </Navbar.Collapse>
      </Navbar>
    );
  }
}

SlugLoader.propTypes = {
  menuNavigation: PropTypes.shape.isRequired
};
