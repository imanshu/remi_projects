/* @flow */
import React from 'react';
import type { Element } from 'react';

import TextField from 'material-ui/TextField';
import Checkbox from 'material-ui/Checkbox';
import RaisedButton from 'material-ui/RaisedButton';
import { Field, reduxForm, formValueSelector } from 'redux-form';
import { connect } from 'react-redux';
import * as styles from './register.scss';

type Props = {
  info: Object,
  formInfo: Object
};

console.log('Field', Field);
// const required = value => (value ? undefined : 'Required');

let createForm = ({ info, formInfo }: Props): Element<'form'> => {
  const submit = () => {
    console.log('in submit');
    console.log('the formValues are', formInfo);
    const formFieldData = {};
    const formData = document.getElementsByTagName('form')[0];
    const { elements } = formData;
    Object.keys(formInfo).forEach((o, k) => {
      if (elements.namedItem(o)) formFieldData[o] = elements.namedItem(o).value;
    });
    const jsonFormatForApi = {
      login: '',
      password: formFieldData.password,
      email: formFieldData.email,
      firstName: formFieldData.firstName,
      lastName: formFieldData.lastName,
      addresses: [
        {
          items: {
            type: 'test_homeAddress',
            postalCode: formFieldData.postalCode,
            phoneNumber: formFieldData.phoneNumber
          }
        }
      ],
      otherOptions: {
        mobileApp: 'true',
        activeSubscriptionsAsCSV: 'test_receivePromoAndSpecialEvents'
      }
    };
    console.log(
      elements.namedItem('firstName') && elements.namedItem('firstName').value
    );
    console.log('the Object got is', jsonFormatForApi);
  };
  type renderFieldProps = {
    input: Object,
    nameVal: string,
    labelVal: string
  };
  const renderField = ({ input, labelVal, nameVal }: renderFieldProps) => (
    <TextField
      name={nameVal}
      floatingLabelText={labelVal}
      className={styles.inputTextBox}
    />
  );
  return (
    <form>
      <div className={styles.createForm}>
        <div>
          <Field
            nameVal="firstName"
            type="text"
            component={renderField}
            labelVal="Please enter the name"
          />
          <TextField
            name="lastName"
            hintText={info.mf_registration_error_lastname}
            floatingLabelText={info.mf_registration_error_lastname}
            className={styles.inputTextBox}
          />
          <TextField
            name="postalCode"
            hintText="Zip Code"
            floatingLabelText="Zip Code"
            className={styles.inputTextBox}
          />
          <TextField
            name="phoneNumber"
            hintText={info.mf_registration_phone}
            floatingLabelText={info.mf_registration_phone}
            className={styles.inputTextBox}
          />
          <TextField
            name="email"
            hintText={info.mf_registration_email}
            floatingLabelText={info.mf_registration_email}
            className={styles.inputTextBox}
          />
          <TextField
            name="password"
            hintText={info.mf_registration_password}
            floatingLabelText={info.mf_registration_password}
            className={styles.inputTextBox_Password}
          />
        </div>
        <div className={styles.regPasswordRules}>
          {info.mf_registration_password_desc}
        </div>
        <div className={styles.regRewardSection}>
          <div className={styles.regRewardSectionTop}>
            {info.mf_registration_rewards}
          </div>
          <div className={styles.regRewardSectionMid}>
            Link AutoZone Rewards with the Member ID number on the back of your
            AutoZone Rewards card.
          </div>
          <TextField
            hintText="9101000389891796"
            floatingLabelText="Autozone Rewards Member ID"
            className={styles.inputTextBox_AZID}
          />
          <div className={styles.regAZMember_Error}>
            We couldn’t find that ID number. Check against the back of your card
            and try again?
          </div>
        </div>
        <div className={styles.regSubscription}>
          <Checkbox />
          <div>{info.mf_registration_privacy}</div>
          <div className={styles.regReadTerms}>
            {info.mf_registration_TermsandConditions}
          </div>
          <div className={styles.regButtonSection}>
            <RaisedButton
              label={info.mf_registration_createAccount}
              className={styles.regPrimaryBtn}
              onClick={submit}
            />
            <RaisedButton
              label={info.mf_registration_cancel}
              className={styles.regSecondaryBtn}
            />
          </div>
          <div className={styles.regSignInLink}>
            {info.mf_registration_SignIn}
          </div>
        </div>
      </div>
    </form>
  );
};

createForm = reduxForm({
  form: 'registerForm' // a unique name for this form
})(createForm);
const selector = formValueSelector('registerForm');

const CreateForm = connect(({ formInfo }) => {
  // console.log('the form data is', state);

  const formValue = selector(formInfo, 'firstName');
  // console.log(state);
  // const firstName =
  console.log('the  is ', formValue);
  return {
    formInfo
  };
})(createForm);
export default CreateForm;
