/* @flow */
import React from 'react';
import type { Element } from 'react';
import { Grid, Row, Col } from 'react-bootstrap';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import lightBaseTheme from 'material-ui/styles/baseThemes/lightBaseTheme';
import TextField from 'material-ui/TextField';
import Checkbox from 'material-ui/Checkbox';
import RaisedButton from 'material-ui/RaisedButton';
import getMuiTheme from 'material-ui/styles/getMuiTheme';
// import Banner from './Banner';
import * as styles from './register.scss';
import logo from './logo.png';

type Props = { info: Object };

const TestCard = ({ info }: Props): Element<'div'> => (
  <Grid className={styles.registerationPage}>
    <Row className="show-grid">
      <Col xs={12} sm={12} md={12} lg={4}>
        <img alt="Logo Here" src={logo} className={styles.regLogo} />
        <h1>{info.mf_registration_createAccount}</h1>
        <MuiThemeProvider muiTheme={getMuiTheme(lightBaseTheme)}>
          <div className={styles.createForm}>
            <div>
              <TextField
                hintText={info.mf_registration_error_firstname}
                floatingLabelText={info.mf_registration_error_firstname}
                className={styles.inputTextBox}
              />
              <TextField
                hintText={info.mf_registration_error_lastname}
                floatingLabelText={info.mf_registration_error_lastname}
                className={styles.inputTextBox}
              />
              <TextField
                hintText="Zip Code"
                floatingLabelText="Zip Code"
                className={styles.inputTextBox}
              />
              <TextField
                hintText={info.mf_registration_email}
                floatingLabelText={info.mf_registration_email}
                className={styles.inputTextBox}
              />
              <TextField
                hintText={info.mf_registration_email}
                floatingLabelText={info.mf_registration_email}
                className={styles.inputTextBox}
              />
              <TextField
                hintText={info.mf_registration_password}
                floatingLabelText={info.mf_registration_password}
                className={styles.inputTextBox_Password}
              />
            </div>
            <div className={styles.regPasswordRules}>
              {info.mf_registration_password_desc}
            </div>
            <div className={styles.regRewardSection}>
              <div className={styles.regRewardSectionTop}>
                {info.mf_registration_rewards}
              </div>
              <div className={styles.regRewardSectionMid}>
                Link AutoZone Rewards with the Member ID number on the back of
                your AutoZone Rewards card.
              </div>
              <TextField
                hintText="9101000389891796"
                floatingLabelText="Autozone Rewards Member ID"
                className={styles.inputTextBox_AZID}
              />
              <div className={styles.regAZMember_Error}>
                We couldn’t find that ID number. Check against the back of your
                card and try again?
              </div>
            </div>
            <div className={styles.regSubscription}>
              <Checkbox />
              <div>Yes, {info.mf_registration_privacy}</div>
              <div className={styles.regReadTerms}>
                {info.mf_registration_TermsandConditions}
              </div>
              <div className={styles.regButtonSection}>
                <RaisedButton
                  label="Sign Up"
                  className={styles.regPrimaryBtn}
                />
                <RaisedButton
                  label={info.mf_registration_cancel}
                  className={styles.regSecondaryBtn}
                />
              </div>
              <div className={styles.regSignInLink}>
                {info.mf_registration_SignIn}
              </div>
            </div>
          </div>
        </MuiThemeProvider>
      </Col>
      <Col xsHidden lg={8}>
        Banner Here 1234
      </Col>
    </Row>
  </Grid>
);

export default TestCard;
