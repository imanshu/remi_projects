/* @flow */

import type { Dispatch } from './types';
import { fetchUsersIfNeeded } from './actions/users';
import { fetchUserIfNeeded } from './actions/user';
import { loadViewForm } from './actions/loadView';
import HomePage from './containers/Home';
import UserInfoPage from './containers/UserInfo';
import NotFoundPage from './containers/NotFound';
// import NavInfoPage from './containers/NavInfo';

import CreateAccountPage from './containers/Create';

export default [
  {
    path: '/',
    exact: true,
    component: HomePage, // Add your route here
    loadData: (dispatch: Dispatch) =>
      Promise.all([
        dispatch(fetchUsersIfNeeded()) // Register your server-side call action(s) here
      ])
  },

  {
    path: '/UserInfo/:id',
    component: UserInfoPage,
    loadData: (dispatch: Dispatch, params: Object) =>
      Promise.all([dispatch(fetchUserIfNeeded(params.id))])
  },

  // {
  //   path: '/Home/:title',
  //   component: NavInfoPage,
  //   loadData: (dispatch: Dispatch, params: Object) =>
  //     Promise.all([dispatch(fetchUserIfNeeded(params.title))])
  // },

  {
    path: '/Home/CreateAccount',
    component: CreateAccountPage
  },

  {
    path: '*',
    component: NotFoundPage
  }
];
