/***********
 * Redux actions file.
 *
 * All your actions should be declared here.
 ***********/

import * as types from 'actionTypes';
import * as api from 'api';

/**
 * This is an action to mock a login API call, for your reference.
 */
export function login() {
    return dispatch => {
        return api.login()
            .then(user => {
                return dispatch({ type: types.APP_LOGIN, payload: { user } })
            });
    }
}

export function getCompletedTasks() {
    return dispatch => {
        return api.getTasks(true)
        .then(tasks => {
            const taskArr=[];
            tasks.map(task => api.getTask(task.id).then(taskDet=>{
                taskArr.push(taskDet);
                if(tasks.length === taskArr.length)
                return dispatch({ type: types.GET_COMPLETED_TASKS, payload: { taskArr } })
            }))
         })
    }
}
export function getInCompletedTasks() {
    return dispatch => {
        return api.getTasks(false)
            .then(tasks => {
                const taskArr=[];
                tasks.map(task => api.getTask(task.id).then(taskDet=>{
                    taskArr.push(taskDet);
                    if(tasks.length === taskArr.length)
                    return dispatch({ type: types.GET_INCOMPLETED_TASKS, payload: { taskArr } })
                }))
             })
                
           
    }
}

export function updateData(task) {
    return dispatch => {
        return api.putTask(task.id,task)
            .then(taskIdUpdated => {
                    console.log(taskIdUpdated);
                    api.getTask(taskIdUpdated.id).then(v=>{
                        if(v.completedDateTime){
                            return dispatch({ type: types.PUT_UPDATED_COMPLETED_TASKS, payload: { task:v } })
                        }else
                        return dispatch({ type: types.PUT_UPDATED_INCOMPLETED_TASKS, payload: { task:v } })

                    }
                );
                    //return dispatch({ type: types.PUT_UPDATED_TASKS, payload: { taskIdUpdated } })
                
             })
                
           
    }
}

