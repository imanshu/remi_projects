function iter(init){
    if(init>0 && init<5){
    console.log(init)
    setTimeout(()=>iter(init-1),1000);
    
    }
    
    }