/***********
 * Redux reducer file.
 *
 * All your reducer logic can go in this file in appReducer.
 ***********/

import { routerReducer } from "react-router-redux";
import { combineReducers } from "redux";
import * as types from "actionTypes";

const initialState = {
    user: null,
    completedTasks:[],
    inCompletedTasks:[],
    updatedStatus:false
};

function appReducer(state = initialState, action) {
    switch (action.type) {
        // add your app actions here
        case types.GET_COMPLETED_TASKS: {
            return {...state, completedTasks: action.payload.taskArr};
        }
        case types.GET_INCOMPLETED_TASKS: {
            return { ...state, inCompletedTasks: action.payload.taskArr };
        }
        case types.APP_LOGIN: {
            return { ...state, user: action.payload.user };
        }
        case types.PUT_UPDATED_COMPLETED_TASKS: {
            return {...state, 
                completedTasks: [...state.completedTasks.filter(v=>v.id !== action.payload.task.id), action.payload.task],
                inCompletedTasks: [...state.inCompletedTasks.filter(v=>v.id !== action.payload.task.id)],
                updatedStatus: !state.updatedStatus
                };
        }
        case types.PUT_UPDATED_INCOMPLETED_TASKS: {
            return {...state, 
                inCompletedTasks: [...state.inCompletedTasks.filter(v=>v.id !== action.payload.task.id),action.payload.task],
                completedTasks: [...state.completedTasks.filter(v=>v.id !== action.payload.task.id)],
                updatedStatus: !state.updatedStatus
            };
        }
        default:
            return state;
    }
}

// combine all reducers into one main reducer
const rootReducer = combineReducers({
    app: appReducer,
    routing: routerReducer
});

export default rootReducer;
