/******
 * Redux action constants.
 *
 * You can add any action constants you need here.
 ******/

export const APP_LOGIN = 'app/LOGIN';

export const GET_COMPLETED_TASKS = 'app/GET_COMPLETED_TASKS';

export const GET_INCOMPLETED_TASKS = 'app/GET_INCOMPLETED_TASKS';

export const PUT_UPDATED_COMPLETED_TASKS = 'app/PUT_UPDATED_COMPLETED_TASKS';


export const PUT_UPDATED_INCOMPLETED_TASKS = 'app/PUT_UPDATED_INCOMPLETED_TASKS';