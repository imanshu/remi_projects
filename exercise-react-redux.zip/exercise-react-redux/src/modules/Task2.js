import React, { Component } from 'react';
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import * as actions from 'actions';

/**
 * Task2 component.
 *
 * You can modify this file however you wish.
 */
class Task2 extends Component {

    constructor(props) {
        super(props);
        this.state = {
            completedTasks:[],
            inCompletedTasks:[],
            completedTasksNew:[],
            inCompletedTasksNew:[],
            updatedStatus:true
        }
    }

    /**
     * This function needs to display the task properly.
     */
    sortByDesc = (tasks) =>{
            return tasks.sort((a,b)=>a.description > b.description);
    }
    submit = ()=>{
        const {completedTasksNew,inCompletedTasksNew} = this.state;
        const { actions } = this.props;
        const alteredTasks = [...completedTasksNew,...inCompletedTasksNew];
        alteredTasks.length >0 && alteredTasks.map(v=>{
            this.setState({updatedStatus:false});
            actions.app.updateData(v);
        })
    }

    markComplete = ()=>{
        let {completedTasks, inCompletedTasks} = this.state;
        const inputRefs = this.refs;
        let inCompletedTasksNew =[];
        let completedTasksNew = [];
        console.log('inputRefs',inputRefs)
        const checkedTasksIds = Object.entries(inputRefs)
                .filter(v=> v[1].checked === true && v[1].getAttribute('data-completed') === "incomplete")
                .map(v=>v[0]);
        
        inCompletedTasksNew = inCompletedTasks.filter(v=>checkedTasksIds.indexOf(String(v.id))=== -1);
        completedTasksNew = inCompletedTasks.filter(v=>checkedTasksIds.indexOf(String(v.id))!== -1);
        completedTasksNew.map(v=>v.completed = true);
        completedTasks.push(...completedTasksNew);
       let newCompleteIds = completedTasksNew.map(v=>v.id);
       this.setState((state)=>{
        return {completedTasks,inCompletedTasks:inCompletedTasksNew,completedTasksNew,
            inCompletedTasksNew: state.inCompletedTasksNew.filter(v=>newCompleteIds.indexOf(v.id)=== -1)};
       });
    }

    markInComplete = ()=>{
        let {completedTasks, inCompletedTasks} = this.state;
        const inputRefs = this.refs;
        let inCompletedTasksNew =[];
        let completedTasksNew = [];
        const checkedTasksIds = Object.entries(inputRefs)
                .filter(v=> v[1].checked === true && v[1].getAttribute('data-completed') === "completed")
                .map(v=>v[0]);
        
        completedTasksNew = completedTasks.filter(v=>checkedTasksIds.indexOf(String(v.id))=== -1);
        inCompletedTasksNew = completedTasks.filter(v=>checkedTasksIds.indexOf(String(v.id))!== -1);
        inCompletedTasksNew.map(v=>v.completed = false);
        inCompletedTasks.push(...inCompletedTasksNew);
        let newInCompleteIds = inCompletedTasksNew.map(v=>v.id);
       this.setState((state)=>{
        return {inCompletedTasks,completedTasks:completedTasksNew,inCompletedTasksNew,
            completedTasksNew: state.completedTasksNew.filter(v=>newInCompleteIds.indexOf(v.id)=== -1)};
       }); 
    }

    buildTasks = task => {
        return (
            <div key={task.id}  class="task">
                <input type="checkbox" ref={task.id} value='off' data-completed={task.completed ? 'completed' : 'incomplete'}/>
                <span>{task.description}</span>
        {task.completedDateTime && <span>({task.completedDateTime})</span>}
            </div>
        )
    };

    buildTodoTable = tasks => {
        return (
            <div class="left">
                <h3>To-Do</h3>
                {tasks.length === 0 || !this.state.updatedStatus ? (<h4>Loading...</h4>) : (<div class="table" ref={this.completedTable}>
                    {tasks.map(this.buildTasks)}
                </div>)}
                {tasks.length !== 0 && this.state.updatedStatus && <button onClick={this.markComplete}>Mark Completed</button>}
            </div>
        )
    };

    buildCompletedTable = tasks => {
        return (
            <div class="right">
                <h3>Completed</h3>
                {tasks.length === 0 || !this.state.updatedStatus  ? (<h4>Loading...</h4>) : (<div class="table" ref={this.completedTable}>
                    {tasks.map(this.buildTasks)}
                </div>)}
                
                {tasks.length !== 0 && this.state.updatedStatus && <button onClick={this.markInComplete}>Mark To-Do</button>}
            </div>
        )
    };

    componentWillMount = () =>{
            const { actions } = this.props;
            actions.app.getCompletedTasks();
            actions.app.getInCompletedTasks();
    }
    shouldComponentUpdate(nextProps,nextState){
        console.log('completed',nextProps.completedTasks.length);
        console.log('incomplete',nextProps.inCompletedTasks.length);
        if((nextState.completedTasks.length) !== (this.state.completedTasks.length) 
            || (nextState.inCompletedTasks.length) !== (this.state.inCompletedTasks.length)
            || (nextState.updatedStatus !== this.state.updatedStatus)){
            return true;
        }
        return false;
    }
    componentWillReceiveProps(nextProps){
       if((nextProps.completedTasks.length) !== (this.props.completedTasks.length)){
            this.setState({completedTasks:this.sortByDesc(nextProps.completedTasks)});
       }
       if((nextProps.inCompletedTasks.length) !== (this.props.inCompletedTasks.length)){
        this.setState({inCompletedTasks:this.sortByDesc(nextProps.inCompletedTasks)});
   }
       if((nextProps.updatedStatus !== this.props.updatedStatus)){
            this.setState({updatedStatus:true,
                completedTasks:this.sortByDesc(nextProps.completedTasks),
                inCompletedTasks:this.sortByDesc(nextProps.inCompletedTasks)
            });
       }
    }
    render() {
        
        const {completedTasks,inCompletedTasks} = this.state;
        

        return (
            <div class="task-table">
                {this.buildTodoTable(inCompletedTasks)}
                {this.buildCompletedTable(completedTasks)}
                <button  onClick={this.submit} type="submit">Submit</button>
                
            </div>
        );
    }
}

/**
 * These functions connect the component to the redux store.
 * They are here for your convenience, and you do not have to use them.
 */
function mapStateToProps(state) {
    return {
    completedTasks: state.app.completedTasks,
    inCompletedTasks: state.app.inCompletedTasks,
    updatedStatus: state.app.updatedStatus
    };
}

function mapDispatchToProps(dispatch) {
    return {
        actions: {
            app: bindActionCreators(actions, dispatch)
        }
    };
}

export default connect(mapStateToProps, mapDispatchToProps)(Task2);
