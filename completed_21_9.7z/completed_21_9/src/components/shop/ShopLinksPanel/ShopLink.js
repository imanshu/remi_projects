 import React,{PropTypes} from 'react';
 import {Link} from 'react-router';
  const ShopLink=({shopData})=>{
	return(
	<div className="views-row">
        <div className="views-field views-field-name"><span className="field-content"><a href="/shop/category/116">{shopData.name}</a></span>
        </div>
    </div>
		);
 }
export default ShopLink;