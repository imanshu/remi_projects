import * as types from './actionTypes';

import axios from 'axios';
export function loadShopCategoriesOnSuccess(shopCategories){
	return {type:types.LOAD_SHOPCATEGORIES_ON_SUCCESS,shopCategories}
}
export function loadShopCategories(){
	return function(dispatch){
		
		return axios.get(`https://mepclouddemoqu478vdavx.devcloud.acquia-sites.com/shop/category/export/major`)
				.then(shopCategories=>{
					console.log(shopCategories.data);
					dispatch(loadShopCategoriesOnSuccess(shopCategories.data));
				})
				.catch(error=>{
					throw(error);
				})
	};
}