export default {
	authors:[],
	courses:[],
	articles:[],
	shopCategories:[],
	ajaxCallsInProgress:0
}