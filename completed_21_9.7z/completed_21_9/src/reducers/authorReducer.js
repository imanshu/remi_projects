import * as types from '../actions/actionTypes';
import initialState from './initialState';
export default function authorReducer(state=initialState.authors,action){
	
	switch(action.type)
	{
		case 'CREATE_COURSE':
		return [...state,Object.assign({},action.course)];
		case 'DELETE_COURSE':
		return Object.keys(state).reduce((result, key)=>{if(key!=Number(action.key)){
			result[key]=state[key];
		}
		return result;
			},[]);
		case 'UPDATE_COURSE':
		return Object.keys(state).reduce((result, key)=>{if(key==Number(action.key)){
			result[key]=state[key];
			result[key]=action.course;
			
		}
		else
		{
			result[key]=state[key];
		}
		return result;
			},[]);
		default:
		return state;
		case 'LOAD_AUTHORS_ON_SUCCESS':
		return action.authors;
	}
	
}