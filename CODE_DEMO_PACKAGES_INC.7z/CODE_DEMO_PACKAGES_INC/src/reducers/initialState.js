export default {
	authors:[],
	courses:[],
	articles:[],
	shopMajorCategories:[],
	shopAllCategories:[],
	ajaxCallsInProgress:0,
	productDetails:[]
}