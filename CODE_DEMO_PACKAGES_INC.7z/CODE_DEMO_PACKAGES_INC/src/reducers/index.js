import {combineReducers} from 'redux';
import articles from './articleReducer';
import shopMajorCategories from './shopMajorCategoryReducer';
import shopAllCategories from './shopAllCategoryReducer';
import productDetails from './productDetailReducer';
import ajaxCallsInProgress from './ajaxStatusReducer';
const rootReducer=combineReducers({
	articles,
	shopMajorCategories,
	shopAllCategories,
	ajaxCallsInProgress,
	productDetails

});
export default rootReducer;
