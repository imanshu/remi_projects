import initialState from './initialState';
export default function shopMajorCategoryReducer(state=[],action){
	
	switch(action.type)
	{

		case 'LOAD_SHOPCATEGORIES_ON_SUCCESS':
		return action.shopCategories;

		default:
		return state;

	}
	
}