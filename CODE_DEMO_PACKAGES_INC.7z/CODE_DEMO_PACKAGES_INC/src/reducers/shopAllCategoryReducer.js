import initialState from './initialState';
export default function shopAllCategoryReducer(state=[],action){
	
	switch(action.type)
	{


		case 'LOAD_SHOPSUBCATEGORIES_ON_SUCCESS':
		return action.shopSubCategories;
		default:
		return state;

	}
	
}