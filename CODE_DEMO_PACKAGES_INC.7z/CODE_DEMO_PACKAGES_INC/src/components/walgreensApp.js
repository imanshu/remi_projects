import React,{PropTypes} from 'react';
import Header from './common/WalHeader';
import Footer from './common/WalFooter';


import {connect} from 'react-redux';

class App extends React.Component{
	render(){
		return(
	<div className="dialog-off-canvas__main-canvas" data-off-canvas-main-canvas>
        <div className="site-wrap">
          <div className="off-canvas-wrap" data-offcanvas>
            <div className="inner-wrap" id="inner-wrap">
              <aside className="left-off-canvas-menu" role="complementary">
              </aside>
              <aside className="right-off-canvas-menu" role="complementary">
              </aside>
              <Header />

            {this.props.children}

        <Footer />
            </div>
           </div>
         </div>
      </div>

		);
	}
}

export default App;