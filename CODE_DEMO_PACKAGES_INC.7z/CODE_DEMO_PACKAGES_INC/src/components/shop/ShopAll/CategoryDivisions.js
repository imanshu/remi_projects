 import React,{PropTypes} from 'react';
 import {Link} from 'react-router';
  const CategoryDivisions=({subCategory})=>{

  	return (
  		 
  		 	<div className="views-col clearfix col-1" style={{width: '25%'}}>
  		 		<div className="views-field views-field-name"><span className="field-content"><a href={"/shop/category/"+subCategory.cat_id}>{subCategory.cat_name}</a></span></div>
  		 	</div>
  		 
  		);
  }

export default CategoryDivisions;