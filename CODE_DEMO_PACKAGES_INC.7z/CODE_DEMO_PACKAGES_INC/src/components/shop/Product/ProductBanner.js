 import React,{PropTypes} from 'react';
 import {Link} from 'react-router';
  const ProductBanner=()=>{
  	const DrupalHost='https://mepclouddemoqu478vdavx.devcloud.acquia-sites.com';
 	return(
<section id="block-beautyhero" data-block-plugin-id="block_content:f34a2bcf-ab61-4038-afce-ba8e14080c22" className="block-beautyhero block-content-type-hero block-plugin-id-block-content block-content block-content__hero block-content__hero--full">
        <div className="hero-block block-content__content block-content__content--hero block-content__content--hero--full">
          <div className="full-width-row l-over-each">
            <div className="l-over-each__item l-over-each__nested-img l-over-each__nested-img--hero hero-alignment-center">
              <div className="field-wrapper field field-block-content--field-hero-image field-name-field-hero-image field-type-image field-label-hidden">
                <div className="field-items">
                  <div className="field-item">    <picture>
                      
                      {/*[if IE 9]></video><![endif]*/}
                      <img src={DrupalHost+"/sites/default/files/styles/hero_image/public/Beauty.jpg"} alt typeof="foaf:Image" />
                    </picture>
                  </div>
                </div>
              </div>
            </div>
          </div></div>
      </section>
 		);
 }

 export default ProductBanner;