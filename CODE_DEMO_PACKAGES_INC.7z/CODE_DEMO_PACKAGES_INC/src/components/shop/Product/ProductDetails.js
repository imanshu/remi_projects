import React,{PropTypes} from 'react';
 import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import {Link} from 'react-router';
import ProductBanner from './ProductBanner';
import Product from './Product';
import * as shopActions from '../../../actions/shopActions';


class ProductDetails extends React.Component{
		constructor(props,context){
		super(props,context);
		this.state={
			productDetails:[],
		};
	}

componentWillReceiveProps(nextProps){
	console.log(nextProps);
	if(nextProps.productDetails){
			if(this.props.params.id!==nextProps.params.id)
		this.setState({productDetails:Object.assign([],nextProps.productDetails)});
	}


}
	componentWillMount(){
		this.props.actions.loadProductDetails(this.props.params.id);
	}
	render(){
		const {productDetails,params}=this.props;
	
		return(
	 <div className="region region-content">
	 	{params.id == '116' && <ProductBanner />}
	 	<section id="block-obio-page-content" data-block-plugin-id="system_main_block" className="block-obio-page-content block-plugin-id-system-main-block">
        <div className="views-element-container"><div className="view view-catalog-taxonomy view-id-catalog_taxonomy view-display-id-page_1 js-view-dom-id-65b12e1ea1bcf9b23a2387572797e633f6ccd8fab763430ee68b45ee937ce620">
            <div className="view-content">
              <div className="views-view-grid horizontal cols-6 clearfix">
               		{productDetails.map((productDetail,key)=> <Product key={key} productDetail={productDetail} />)}
               </div>
               </div>
              </div>
             </div>
            </section>
	 </div>
			);
	}

}
function mapStateToProps(state,ownProps)
{
	let productId=ownProps.params.id; //parameters passed over the Router(router parameters)
		
	return{
		productDetails:state.productDetails
	};
}
function mapDispatchToProps(dispatch){
	
	return{
		actions: bindActionCreators(shopActions,dispatch)
	};
}
export default connect(mapStateToProps,mapDispatchToProps)(ProductDetails);
