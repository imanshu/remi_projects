 import React,{PropTypes} from 'react';
 import {Link} from 'react-router';
 import ShopLink from './ShopLink';

 const ShopLinksPanel=({shopLinks})=>{
	return(
	
        <section id='displayShopLinks' className="views-element-container block-views-block-catalog-taxonomy-block-2 block-plugin-id-views-block" id="block-views-block-catalog-taxonomy-block-2" data-block-plugin-id="views_block:catalog_taxonomy-block_2">
          <h2 className="block-title">Shop</h2>
          <div>
            <div className="view view-catalog-taxonomy view-id-catalog_taxonomy view-display-id-block_2 js-view-dom-id-624c9758ff40d409a73701a3821ebc19c6a365d48ec38ad984c21dc65f54f9d3">
              <div className="view-content">
              {
              	shopLinks && shopLinks.map((shopData,key)=>{
              		return <ShopLink key={key} shopData={shopData} />;
              })
          }
              </div>
             </div>
            </div>
           </section>
        
		);
 }
export default ShopLinksPanel;