
import React,{PropTypes} from 'react';
 import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import {Link} from 'react-router';
import ShopAllCategories from './ShopAll/ShopAllCategories'; 
import * as shopActions from '../../actions/shopActions';



class shopCategories extends React.Component{
		constructor(props,context){
		super(props,context);
		this.state={
			shopCategories:[]
		};
	}

	render(){
		const {shopCategories}=this.props;
		return(
	<div className="row main-wrap align-center">
        <main id="main" className="shop columns" role="main">
          <a id="main-content" />
           <section>
           		{this.props.children}
           		<ShopAllCategories/>
           </section>
		</main>
	 </div>
			);
	}

}
function mapStateToProps(state,ownProps)
{
	return{
		shopCategories:state.shopCategories
	};
}
function mapDispatchToProps(dispatch){
	return{
		actions: bindActionCreators(shopActions,dispatch)
	};
}
export default connect(mapStateToProps,mapDispatchToProps)(shopCategories);
