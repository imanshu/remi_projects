 import React,{PropTypes} from 'react';
 import {Link} from 'react-router';
 import ShopDisplay from './ShopDisplay';
 const ShopDisplayList=({shopList})=>{
 	console.log('inisde ShopDisplayList',shopList);
 	return(
<section id="block-obio-page-content" data-block-plugin-id="system_main_block" className="block-obio-page-content block-plugin-id-system-main-block">
    <div className="views-element-container">
        <div className="view view-catalog-taxonomy view-id-catalog_taxonomy view-display-id-page_2 js-view-dom-id-7d4a73ba21cea4f914801576e98013dbea7f2b3c564ad0f578df7716a7e6a8af">
            <div className="view-content">
                <div className="views-view-grid horizontal cols-3 clearfix">
                    <div className="product-grid-row views-row clearfix row-1">
                    {
                    	shopList && shopList.map((shopDetail,key)=>{
                    			
                    			return  <ShopDisplay key={key} shopDetail={shopDetail} />;
                    })
                }
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
 		);
 }

 export default ShopDisplayList;