 import React,{PropTypes} from 'react';


 const Article=({articleData,hostName})=>{
 	
 	
 	
 	return(
 		 <li className="columns">
                                          <article data-history-node-id={171} role="article" about="/content/health-article" typeof="schema:Article" className="node node--type-article node--promoted node--view-mode-card l-card-elem">
                                            <div className="card">
                                              <div className="card__media">
                                                <div className="image field field-node--field-image field-name-field-image field-type-image field-label-visually_hidden">
                                                  <div className="field-label visually-hidden">Image</div>
                                                  <div className="field-items">
                                                    <div className="field-item">  <a href="/content/health-article">  <img property="schema:image" srcSet={hostName+articleData.field_image} src={hostName+articleData.field_image} alt={articleData.title} typeof="foaf:Image" />
                                                      </a>
                                                    </div>
                                                  </div>
                                                </div>
                                              </div>    
                                              <div className="view-mode-card card__content-wrapper">
                                                <div className="card__content">
                                                  <h2 className="node-title card__title">
                                                    <a href="/content/health-article" rel="bookmark"><span property="schema:name" className="field-wrapper">{articleData.title}</span>
                                                    </a>
                                                  </h2>
                                                  <span property="schema:name" content="Health Article" className="hidden" />
                                                  <span property="schema:interactionCount" content="UserComments:0" className="hidden" />
                                                  <div className="field-wrapper field field-node--field-article-subtitle field-name-field-article-subtitle field-type-string field-label-visually_hidden">
                                                    <div className="field-label visually-hidden">Subtitle</div>
                                                    <div className="field-items">
                                                      <div className="field-item">{articleData.field_article_subtitle}</div>
                                                    </div>
                                                  </div>
                                                </div>
                                              </div>
                                            </div>
                                          </article>
                                        </li>
 		);
 }
export default Article;