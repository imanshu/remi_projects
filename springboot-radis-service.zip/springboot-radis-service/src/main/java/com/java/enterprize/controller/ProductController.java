package com.java.enterprize.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.java.enterprize.application.RadisServiceApplication;
import com.java.enterprize.domain.Product;
import com.java.enterprize.repository.ProductRepository;

@Controller
public class ProductController {
   
	private static final Logger logger = LoggerFactory.getLogger(ProductController.class);
	
	//@Autowired
	//ProductRepository repository; 
	
	@RequestMapping(value = "/product/v1/{id}" ,method = RequestMethod.GET)
	@Cacheable("Product")
	public Product findById(@PathVariable("id") String id) {
		
		//Product product = repository.getById(Integer.parseInt(id));
		Product product = new Product(1,"a","b","c");
		
		return product ;
	}
	
	@RequestMapping(value = "/check" ,method = RequestMethod.GET)
	@ResponseBody
	public String checkData() {
		
		logger.info("connecting to redis......");
		//Product product = repository.getById(Integer.parseInt(id));
		//Product product = new Product(1,"a","b","c");
		
		return "hi-redis" ;
	}
}
