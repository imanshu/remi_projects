package com.java.enterprize.domain;

import com.datastax.driver.mapping.annotations.Column;
import com.datastax.driver.mapping.annotations.PartitionKey;
import com.datastax.driver.mapping.annotations.Table;

import lombok.Data;


	

@Table(keyspace = "apikeyspace",
name = "products",
readConsistency = "QUORUM",
writeConsistency = "QUORUM",
caseSensitiveKeyspace = false,
caseSensitiveTable = false)
@Data
public class Product {
	
	@PartitionKey
	@Column(name = "id")
	private int id;
	
	@Column(name = "name")
	private String name;
	
	@Column(name = "reviews")
	private String reviews;

	
	@Column(name = "unit_price")
	private String unitPrice;
	
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(String unitPrice) {
		this.unitPrice = unitPrice;
	}

	public String getReviews() {
		return reviews;
	}

	public void setReviews(String reviews) {
		this.reviews = reviews;
	}

	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", reviews=" + reviews + ", unitPrice=" + unitPrice + "]";
	}

	public Product(int id, String name, String unitPrice, String reviews) {
		super();
		this.id = id;
		this.name = name;
		this.unitPrice = unitPrice;
		this.reviews = reviews;
	}

	public Product() {
		super();
	}
}
